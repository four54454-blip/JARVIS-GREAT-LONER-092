import unittest
from unittest.mock import patch

import numpy as np

from core.avatar import FACE_EMOTIONS, HoloAvatar
from memory import config_manager
from providers.schema import CORE_TOOLS, budget


class FaceEmotionTests(unittest.TestCase):
    def test_supported_emotions_fade_back_to_neutral(self):
        avatar = HoloAvatar()
        self.assertEqual(
            FACE_EMOTIONS,
            (
                "neutral", "happy", "amused", "playful", "excited", "curious",
                "confused", "skeptical", "surprised", "fearful", "concerned",
                "sad", "empathetic", "frustrated", "angry", "disgusted",
                "relieved", "apologetic", "confident", "calm",
            ),
        )
        self.assertTrue(avatar.set_emotion("happy", hold=0.1))
        for _ in range(4):
            avatar.step(0.05, 0.0)
        self.assertGreater(avatar._emotion.smile, 0.0)

        for _ in range(30):
            avatar.step(0.05, 0.0)
        self.assertAlmostEqual(avatar._emotion.smile, 0.0, delta=0.01)

    def test_disabled_emotions_reject_new_expressions_and_relax(self):
        avatar = HoloAvatar()
        self.assertTrue(avatar.set_emotion("sad"))
        for _ in range(8):
            avatar.step(0.05, 0.0)

        avatar.set_emotions_enabled(False)
        self.assertFalse(avatar.set_emotion("happy"))
        for _ in range(30):
            avatar.step(0.05, 0.0)
        self.assertAlmostEqual(avatar._emotion.smile, 0.0, delta=0.01)
        self.assertFalse(avatar.set_emotion("unknown"))

    def test_surprise_opens_the_eyes(self):
        avatar = HoloAvatar()
        self.assertTrue(avatar.set_emotion("surprised"))
        for _ in range(24):
            avatar.step(0.05, 0.0, state="LISTENING")
        self.assertGreater(avatar._lids, 1.0)
        self.assertGreater(avatar._jaw_expression, 0.0)

    def test_sleeping_closes_eyes_even_during_an_expression(self):
        avatar = HoloAvatar()
        self.assertTrue(avatar.set_emotion("surprised", hold=20.0))

        for _ in range(60):
            avatar.step(0.05, 0.0, state="SLEEPING")

        self.assertLess(avatar._lids, 0.01)

    def test_blink_closes_and_reopens_without_snapping(self):
        avatar = HoloAvatar()
        avatar._blink_at = 0.0

        avatar.step(0.016, 0.0, state="LISTENING")
        avatar.step(0.016, 0.016, state="LISTENING")
        first_frame = avatar._blink
        self.assertGreater(first_frame, 0.0)
        self.assertLess(first_frame, 1.0)

        peak = first_frame
        for _ in range(20):
            avatar.step(0.016, 0.0, state="LISTENING")
            peak = max(peak, avatar._blink)

        self.assertGreater(peak, 0.9)
        self.assertLess(avatar._blink, 0.1)

    def test_expression_channels_transition_at_different_speeds(self):
        avatar = HoloAvatar()
        avatar.set_emotion("curious")

        avatar.step(0.1, 0.0, state="LISTENING")

        gaze_progress = avatar._emotion.gaze_x / avatar._emotion_target.gaze_x
        head_progress = avatar._emotion.yaw / avatar._emotion_target.yaw
        self.assertGreater(gaze_progress, head_progress)

    def test_thinking_state_spaces_blinks_out_more_than_listening(self):
        listening = HoloAvatar()
        thinking = HoloAvatar()
        listening._blink_at = 0.0
        thinking._blink_at = 0.0

        with patch("core.avatar.random.uniform", return_value=1.0):
            listening.step(0.016, 0.0, state="LISTENING")
            thinking.step(0.016, 0.0, state="THINKING")

        self.assertGreater(thinking._blink_at, listening._blink_at)

    def test_speaking_microexpressions_deform_face_geometry(self):
        avatar = HoloAvatar()
        avatar._speaking = True
        avatar._expr = 0.24
        avatar._emph = 0.35
        avatar._speech_brow_asym = 0.12
        speaking_vertices = avatar._pose()[0].copy()

        avatar._speaking = False
        resting_vertices = avatar._pose()[0]

        self.assertGreater(
            float(np.max(np.abs(speaking_vertices - resting_vertices))),
            0.001,
        )

    def test_all_emotion_profiles_are_unique_and_accepted(self):
        avatar = HoloAvatar()
        poses = set()
        for emotion in FACE_EMOTIONS:
            self.assertTrue(avatar.set_emotion(emotion))
            poses.add(avatar._emotion_target)
        self.assertEqual(len(poses), len(FACE_EMOTIONS))

    def test_face_emotion_tool_survives_small_model_tool_budget(self):
        declarations = [
            {"name": name, "tier": "core", "brief": name}
            for name in CORE_TOOLS
        ]
        selected = budget(declarations, max_tools=8)
        self.assertIn("set_face_emotion", [item["name"] for item in selected])

    def test_emotion_setting_defaults_on_and_persists_through_config_helper(self):
        with patch.object(config_manager, "load_api_keys", return_value={}):
            self.assertTrue(config_manager.get_face_emotions_enabled())

        with patch.object(config_manager, "load_api_keys",
                          return_value={"face_emotions_enabled": False}):
            self.assertFalse(config_manager.get_face_emotions_enabled())

        with patch.object(config_manager, "_save_flag") as save_flag:
            config_manager.save_face_emotions_enabled(False)
        save_flag.assert_called_once_with("face_emotions_enabled", False)

if __name__ == "__main__":
    unittest.main()
