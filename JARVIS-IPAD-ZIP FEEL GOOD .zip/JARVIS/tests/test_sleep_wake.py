import asyncio
import unittest
from unittest.mock import Mock, patch

from main import JarvisLive


class SleepWakeTests(unittest.TestCase):
    @staticmethod
    def _jarvis():
        jarvis = object.__new__(JarvisLive)
        jarvis._lock_mode_active = False
        jarvis._awake = True
        jarvis._wake_enabled = False
        jarvis._sleep_wake_override = False
        jarvis._wake_detector = None
        jarvis.ui = Mock()
        jarvis.ui.muted = False
        jarvis._discard_pending_input_audio = Mock()
        jarvis._drain_audio_output = Mock()
        jarvis.session = Mock()
        return jarvis

    def test_sleep_enables_local_wake_gate_and_wake_restores_setting(self):
        jarvis = self._jarvis()

        with patch.object(jarvis, "_ensure_wake_detector", return_value=True):
            ready = asyncio.run(jarvis._enter_sleep("spoken command"))

        self.assertTrue(ready)
        self.assertFalse(jarvis._awake)
        self.assertTrue(jarvis._wake_enabled)
        self.assertTrue(jarvis._sleep_wake_override)
        jarvis.ui.set_state.assert_called_once_with("SLEEPING")
        jarvis.session.send_client_content.assert_not_called()

        jarvis._queue_welcome_greeting = Mock()
        jarvis.wake()

        self.assertTrue(jarvis._awake)
        self.assertFalse(jarvis._wake_enabled)
        self.assertFalse(jarvis._sleep_wake_override)
        jarvis._queue_welcome_greeting.assert_called_once_with()

    def test_unavailable_wake_detector_leaves_jarvis_asleep_without_speech(self):
        jarvis = self._jarvis()
        with patch.object(jarvis, "_ensure_wake_detector", return_value=False):
            ready = asyncio.run(jarvis._enter_sleep("spoken command"))

        self.assertFalse(ready)
        self.assertFalse(jarvis._awake)
        self.assertTrue(jarvis._wake_enabled)
        jarvis.ui.set_state.assert_called_once_with("SLEEPING")
        jarvis.ui.write_log.assert_any_call(
            "ERR: Wake word is unavailable; tap WAKE NOW to wake JARVIS."
        )
        jarvis.session.send_client_content.assert_not_called()


if __name__ == "__main__":
    unittest.main()
