"""Launch the JARVIS host used by its installable browser dashboard.

The host remains responsible for desktop tools and local files; the PWA is a
paired client served by the existing FastAPI dashboard.
"""

from main import main


if __name__ == "__main__":
    main()
