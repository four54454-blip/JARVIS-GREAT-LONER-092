import os
import unittest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PyQt6.QtCore import QPointF, QRectF
from PyQt6.QtGui import QColor, QImage, QPainter
from PyQt6.QtWidgets import QApplication

from gui.avatar_drawing import (
    DrawingBoard,
    _connection_edge,
    _path_for_part,
    _part_center,
    normalize_visual_explanation,
)
from main import TOOL_DECLARATIONS


_STEAM_ENGINE = {
    "title": "How a Steam Engine Moves",
    "subtitle": "Heat becomes motion through expanding steam.",
    "components": [
        {
            "shape": "flame", "x": 0.13, "y": 0.55,
            "width": 0.09, "height": 0.18, "label": "FIRE",
            "step": 0,
        },
        {
            "shape": "boiler", "x": 0.35, "y": 0.49,
            "width": 0.24, "height": 0.25, "label": "BOILER",
            "step": 0,
        },
        {
            "shape": "valve", "x": 0.57, "y": 0.49,
            "width": 0.09, "height": 0.12, "label": "VALVE",
            "step": 1,
        },
        {
            "shape": "piston", "x": 0.75, "y": 0.49,
            "width": 0.16, "height": 0.18, "label": "PISTON",
            "step": 1,
        },
        {
            "shape": "wheel", "x": 0.81, "y": 0.76,
            "width": 0.18, "height": 0.18, "label": "WHEEL",
            "step": 2,
        },
    ],
    "connections": [
        {"from": 0, "to": 1, "label": "HEAT", "step": 0},
        {"from": 1, "to": 2, "label": "STEAM", "step": 1},
        {"from": 2, "to": 3, "label": "PRESSURE", "step": 1},
        {"from": 3, "to": 4, "label": "ROD", "step": 2},
    ],
    "steps": [
        {"title": "Make steam", "explanation": "Fire heats water in the boiler."},
        {"title": "Push the piston", "explanation": "Steam pressure drives the piston."},
        {"title": "Turn the wheel", "explanation": "A connecting rod turns the crank wheel."},
    ],
}


class VisualExplanationTests(unittest.TestCase):
    def test_normalizes_process_diagram_and_component_connections(self):
        plan = normalize_visual_explanation(_STEAM_ENGINE)

        self.assertEqual(plan.title, "How a Steam Engine Moves")
        self.assertEqual(len(plan.parts), 5)
        self.assertEqual(len(plan.connections), 4)
        self.assertEqual(plan.steps[1].title, "Push the piston")

    def test_cylinder_component_is_supported_and_renderable(self):
        plan = normalize_visual_explanation({
            "title": "Cylinder",
            "components": [{
                "shape": "cylinder", "x": 0.5, "y": 0.5,
                "width": 0.2, "height": 0.4, "label": "CYLINDER",
            }],
            "steps": [{"title": "Shape", "explanation": "A cylindrical vessel."}],
        })
        path = _path_for_part(plan.parts[0], QRectF(0, 0, 500, 300))

        self.assertFalse(path.isEmpty())
        self.assertAlmostEqual(path.boundingRect().width(), 100)

    def test_visual_tool_schema_includes_cylinder(self):
        tool = next(
            item for item in TOOL_DECLARATIONS
            if item.get("name") == "present_visual_explanation"
        )
        shapes = tool["parameters"]["properties"]["components"]["items"]
        self.assertIn("cylinder", shapes["properties"]["shape"]["enum"])

    def test_rejects_out_of_bounds_and_unsupported_drawing_data(self):
        invalid_position = {
            **_STEAM_ENGINE,
            "components": [
                {**_STEAM_ENGINE["components"][0], "x": 1.5},
            ],
        }
        with self.assertRaisesRegex(ValueError, "outside the allowed canvas"):
            normalize_visual_explanation(invalid_position)

        invalid_shape = {
            **_STEAM_ENGINE,
            "components": [
                {**_STEAM_ENGINE["components"][0], "shape": "execute"},
            ],
        }
        with self.assertRaisesRegex(ValueError, "Unsupported drawing shape"):
            normalize_visual_explanation(invalid_shape)

        invalid_connection = {
            **_STEAM_ENGINE,
            "connections": [{"from": 0, "to": 9, "step": 0}],
        }
        with self.assertRaisesRegex(ValueError, "valid components and steps"):
            normalize_visual_explanation(invalid_connection)

    def test_connection_stops_at_component_edges(self):
        plan = normalize_visual_explanation(_STEAM_ENGINE)
        boiler = plan.parts[1]
        fire_center = _part_center(plan.parts[0], QRectF(0, 0, 1000, 600))
        boiler_edge = _connection_edge(boiler, fire_center, QRectF(0, 0, 1000, 600))

        self.assertAlmostEqual(boiler_edge.x(), 230)
        self.assertAlmostEqual(boiler_edge.y(), 313.6363636364)
        self.assertNotEqual(boiler_edge, QPointF(350, 294))

    def test_paper_zoom_and_live_drawing_render_on_the_board(self):
        app = QApplication.instance() or QApplication([])
        board = DrawingBoard()
        board.resize(900, 560)
        board.show()
        app.processEvents()
        board.start(_STEAM_ENGINE)
        board.canvas._elapsed = 2.4
        image = QImage(board.canvas.size(), QImage.Format.Format_ARGB32)
        image.fill(QColor("#000000"))
        painter = QPainter(image)
        board.canvas.render(painter)
        painter.end()

        page_point = image.pixelColor(image.width() // 2, 30)
        self.assertGreater(page_point.red(), 100)
        ink_pixels = 0
        for y in range(image.height()):
            for x in range(image.width()):
                color = image.pixelColor(x, y)
                if color.red() < 45 and color.green() < 90 and color.blue() < 120:
                    ink_pixels += 1
        self.assertGreater(ink_pixels, 300)
        board.canvas.stop()
        board.close()
        app.processEvents()


if __name__ == "__main__":
    unittest.main()
