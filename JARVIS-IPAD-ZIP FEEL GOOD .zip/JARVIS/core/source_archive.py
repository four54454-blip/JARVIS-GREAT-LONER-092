"""Create a portable JARVIS source ZIP without local secrets or personal data."""
from __future__ import annotations

import os
import tempfile
import zipfile
from pathlib import Path


_EXCLUDED_DIRS = {
    ".git", ".venv", "venv", "env", "ENV", "__pycache__", ".pytest_cache",
    ".mypy_cache", ".ruff_cache", ".vscode", ".idea", ".jarvis_backup",
    "Jarvis.app", "Jaden pix", "node_modules", "build", "dist", "reports",
    "logs", "downloads", "screenshots",
}
_EXCLUDED_SUFFIXES = {
    ".pyc", ".pyo", ".db", ".sqlite", ".sqlite3", ".log", ".zip", ".pem",
    ".key", ".p12", ".pfx", ".crt",
}
_EXCLUDED_NAMES = {
    ".ds_store", "api_keys.json", "long_term.json", "routines.json",
    "credentials.json", "token.json", "family_memory.txt",
}
_SECRET_MARKERS = (
    "api_key", "api-key", "apikey", "client_secret", "credential",
    "password", "private_key", "secret", "token",
)


def _excluded(relative: Path) -> bool:
    parts = relative.parts
    name = relative.name.lower()
    suffix = relative.suffix.lower()
    if any(part in _EXCLUDED_DIRS for part in parts):
        return True
    if name in _EXCLUDED_NAMES or name.startswith(".env"):
        return True
    if suffix in _EXCLUDED_SUFFIXES:
        return True
    if (any(marker in name for marker in _SECRET_MARKERS)
            and suffix not in {".py", ".md", ".rst"}):
        return True
    if parts[0] == "memory" and len(parts) > 1 and suffix != ".py":
        return True
    if parts[0] == "config" and suffix not in {".py", ".ico"}:
        return True
    return False


def create_jarvis_source_zip(destination: str | Path,
                             source_root: str | Path | None = None) -> Path:
    """Write a verified, atomic source archive and return its final path."""
    root = Path(source_root or Path(__file__).resolve().parent.parent).resolve()
    if not (root / "main.py").is_file():
        raise FileNotFoundError(f"JARVIS source root is missing main.py: {root}")

    dest = Path(os.path.abspath(os.path.expanduser(str(destination))))
    resolved_dest = dest.resolve()
    for candidate in (dest, resolved_dest):
        try:
            candidate.relative_to(root)
        except ValueError:
            continue
        raise ValueError("Choose a ZIP destination outside the JARVIS source folder.")
    if dest.suffix.lower() != ".zip":
        raise ValueError("The JARVIS source archive destination must end in .zip.")
    if not dest.parent.is_dir():
        raise FileNotFoundError(f"Destination folder does not exist: {dest.parent}")

    temporary_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
                prefix=".jarvis-source-", suffix=".zip",
                dir=dest.parent, delete=False) as temporary:
            temporary_path = Path(temporary.name)

        with zipfile.ZipFile(temporary_path, "w",
                             compression=zipfile.ZIP_DEFLATED,
                             compresslevel=6) as archive:
            count = 0
            for current, dirs, files in os.walk(root, followlinks=False):
                current_path = Path(current)
                relative_dir = current_path.relative_to(root)
                dirs[:] = sorted(
                    name for name in dirs
                    if name not in _EXCLUDED_DIRS
                    and not (current_path / name).is_symlink()
                    and not _excluded(relative_dir / name)
                )
                for name in sorted(files):
                    path = current_path / name
                    relative = path.relative_to(root)
                    if path.is_symlink() or not path.is_file() or _excluded(relative):
                        continue
                    archive.write(path, f"JARVIS/{relative.as_posix()}")
                    count += 1
            if count == 0:
                raise ValueError("No source files were found for the JARVIS archive.")

        with zipfile.ZipFile(temporary_path, "r") as archive:
            corrupt = archive.testzip()
            if corrupt is not None:
                raise zipfile.BadZipFile(f"Archive verification failed at {corrupt}")
        os.replace(temporary_path, dest)
        temporary_path = None
        return dest
    finally:
        if temporary_path is not None:
            try:
                temporary_path.unlink()
            except FileNotFoundError:
                pass
