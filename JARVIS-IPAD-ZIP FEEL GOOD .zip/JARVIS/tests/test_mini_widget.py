import os
import sys
import unittest
from types import ModuleType, SimpleNamespace
from unittest.mock import patch

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PyQt6.QtCore import QPoint, Qt
from PyQt6.QtTest import QTest
from PyQt6.QtWidgets import QApplication

from gui.mini_widget import MiniAssistantWidget, enable_nonactivating_panel
from gui.window import MainWindow
from memory import config_manager


class _VisibilityWidget:
    def __init__(self):
        self.visible = False

    def isVisible(self):
        return self.visible

    def show(self):
        self.visible = True

    def hide(self):
        self.visible = False

    def raise_(self):
        raise AssertionError("Visibility sync must not activate the widget")


class MiniAssistantWidgetTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self.level = 0.0
        self.widget = MiniAssistantWidget(lambda: self.level)
        self.widget.show()
        self.app.processEvents()

    def tearDown(self):
        self.widget.close()
        self.app.processEvents()

    def test_left_click_is_inert_and_right_click_opens_controls(self):
        settings = []
        self.widget.open_settings.connect(lambda: settings.append(True))

        QTest.mouseClick(
            self.widget, Qt.MouseButton.LeftButton, pos=QPoint(10, 22)
        )
        self.assertEqual(settings, [])
        QTest.mouseClick(
            self.widget, Qt.MouseButton.LeftButton,
            pos=QPoint(self.widget.width() - 10, 22),
        )

        self.assertEqual(settings, [True])

    def test_waveform_tracks_the_smoothed_audio_level(self):
        self.level = 0.8
        self.widget._tick()

        self.assertGreater(self.widget._level, 0.4)
        self.assertNotEqual(self.widget._phase, 0.0)
        self.assertEqual(self.widget.size().width(), MiniAssistantWidget._SIZE[0])

    @unittest.skipUnless(sys.platform == "darwin", "macOS-only widget behavior")
    def test_widget_stays_visible_when_jarvis_deactivates(self):
        self.assertTrue(self.widget.testAttribute(
            Qt.WidgetAttribute.WA_MacAlwaysShowToolWindow
        ))

    def test_widget_can_be_dragged(self):
        self.widget.move(60, 60)
        starting_x = self.widget.x()
        QTest.mousePress(
            self.widget, Qt.MouseButton.LeftButton, pos=QPoint(65, 22)
        )
        QTest.mouseMove(self.widget, QPoint(92, 22), 50)
        QTest.mouseRelease(
            self.widget, Qt.MouseButton.LeftButton, pos=QPoint(92, 22)
        )

        self.assertGreater(self.widget.x(), starting_x)

    def test_short_one_finger_drag_uses_release_position(self):
        self.widget.move(60, 60)
        starting_x = self.widget.x()
        QTest.mousePress(
            self.widget, Qt.MouseButton.LeftButton, pos=QPoint(5, 22)
        )
        QTest.mouseRelease(
            self.widget, Qt.MouseButton.LeftButton, pos=QPoint(11, 22)
        )

        self.assertGreater(self.widget.x(), starting_x)

    def test_background_visibility_does_not_raise_widget(self):
        class WindowState:
            _mini_widget_enabled = True
            _mini_widget = _VisibilityWidget()

            def isMinimized(self):
                return False

            def isActiveWindow(self):
                return False

        MainWindow._sync_mini_widget_visibility(WindowState())

        self.assertTrue(WindowState._mini_widget.isVisible())

    def test_widget_settings_toggle_without_restoring_main_window(self):
        drawer = _VisibilityWidget()

        class WindowState:
            _ctrl_drawer = drawer
            _ctrl_btn = SimpleNamespace(checked=False)

            def _close_setup(self):
                pass

            def _refresh_wake_btns(self):
                pass

            def _detach_controls_drawer(self):
                pass

            def _position_ctrl_drawer_for_mini_widget(self):
                pass

        def set_checked(value):
            WindowState._ctrl_btn.checked = value

        WindowState._ctrl_btn.setChecked = set_checked

        MainWindow._open_controls_from_mini_widget(WindowState())
        self.assertTrue(drawer.isVisible())
        self.assertTrue(WindowState._ctrl_btn.checked)

        MainWindow._open_controls_from_mini_widget(WindowState())
        self.assertFalse(drawer.isVisible())
        self.assertFalse(WindowState._ctrl_btn.checked)

    def test_macos_panel_rejects_app_activation(self):
        panel_type = type("NSPanel", (), {})

        class Panel:
            style = 4
            key_only = False

            def isKindOfClass_(self, cls):
                return cls is panel_type

            def styleMask(self):
                return self.style

            def setStyleMask_(self, value):
                self.style = value

            def setBecomesKeyOnlyIfNeeded_(self, value):
                self.key_only = value

        panel = Panel()
        native_view = SimpleNamespace(window=lambda: panel)
        appkit = ModuleType("AppKit")
        appkit.NSPanel = panel_type
        appkit.NSWindowStyleMaskNonactivatingPanel = 128
        objc = ModuleType("objc")
        objc.objc_object = lambda **kwargs: native_view
        fake_app = SimpleNamespace(platformName=lambda: "cocoa")
        fake_application = SimpleNamespace(instance=lambda: fake_app)
        widget = SimpleNamespace(winId=lambda: 123)

        with (
            patch("gui.mini_widget.sys.platform", "darwin"),
            patch("gui.mini_widget.QApplication", fake_application),
            patch.dict(sys.modules, {"AppKit": appkit, "objc": objc}),
        ):
            enable_nonactivating_panel(widget)

        self.assertEqual(panel.style, 4 | 128)
        self.assertTrue(panel.key_only)


class MiniWidgetSettingTests(unittest.TestCase):
    def test_widget_setting_defaults_off_and_persists(self):
        with patch.object(config_manager, "load_api_keys", return_value={}):
            self.assertFalse(config_manager.get_mini_widget_enabled())
        with patch.object(
            config_manager, "load_api_keys",
            return_value={"mini_widget_enabled": True},
        ):
            self.assertTrue(config_manager.get_mini_widget_enabled())
        with patch.object(config_manager, "_save_flag") as save_flag:
            config_manager.save_mini_widget_enabled(True)
        save_flag.assert_called_once_with("mini_widget_enabled", True)


if __name__ == "__main__":
    unittest.main()
