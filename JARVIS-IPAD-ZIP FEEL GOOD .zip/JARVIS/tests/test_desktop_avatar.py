import os
import unittest
from unittest.mock import patch

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PyQt6.QtCore import QPoint, Qt
from PyQt6.QtTest import QTest
from PyQt6.QtWidgets import QApplication

from gui.avatar_scene import DEFAULT_AVATAR_SCENE, AvatarScene
from gui.desktop_avatar import DesktopAvatarOverlay
from gui.hud import HudCanvas


class DesktopAvatarOverlayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        class Hud:
            painted = False
            avatar_scene = DEFAULT_AVATAR_SCENE

            def paint_desktop_avatar(self, _painter, _rect):
                self.painted = True

        self.hud = Hud()
        self.overlay = DesktopAvatarOverlay(self.hud)

    def tearDown(self):
        self.overlay.close()
        self.app.processEvents()

    def test_overlay_paints_live_hud_and_can_be_dragged(self):
        self.overlay.show()
        self.app.processEvents()
        self.assertTrue(self.hud.painted)

        start_x = self.overlay.x()
        QTest.mousePress(
            self.overlay, Qt.MouseButton.LeftButton, pos=QPoint(100, 100)
        )
        QTest.mouseMove(self.overlay, QPoint(130, 100), 30)
        QTest.mouseRelease(
            self.overlay, Qt.MouseButton.LeftButton, pos=QPoint(130, 100)
        )

        self.assertGreater(self.overlay.x(), start_x)

    def test_walking_pose_moves_the_overlay_smoothly_within_the_display(self):
        screen = QApplication.primaryScreen()
        self.assertIsNotNone(screen)
        area = screen.availableGeometry()
        self.overlay.move(area.left() + 10, area.top() + 24)
        self.overlay._walk_direction = 1
        start_x = self.overlay.x()

        self.overlay._last_tick = 0.0
        with patch("gui.desktop_avatar.time.monotonic", return_value=0.5):
            self.overlay._tick()
        self.assertEqual(self.overlay.x(), start_x)

        self.hud.avatar_scene = AvatarScene(pose="walking")
        self.overlay._last_tick = 0.0
        with patch("gui.desktop_avatar.time.monotonic", return_value=0.1):
            self.overlay._tick()

        self.assertGreater(self.overlay.x(), start_x)
        self.assertLessEqual(
            self.overlay.x() + self.overlay.width() - 1, area.right()
        )
        self.assertEqual(self.hud.avatar_scene.pose, "walking")

    def test_close_control_requests_overlay_dismissal(self):
        dismissed = []
        self.overlay.close_requested.connect(lambda: dismissed.append(True))
        self.overlay.show()
        self.app.processEvents()
        QTest.mouseClick(
            self.overlay,
            Qt.MouseButton.LeftButton,
            pos=QPoint(self.overlay.width() - 19, 19),
        )

        self.assertEqual(dismissed, [True])

    def test_desktop_mode_accepts_and_clears_full_body_scenes(self):
        hud = HudCanvas("")
        try:
            hud.set_avatar_body_enabled(False)
            hud.set_desktop_avatar_enabled(True)

            self.assertTrue(hud.set_avatar_scene(AvatarScene(pose="walking")))
            self.assertEqual(hud.avatar_scene.pose, "walking")

            hud.set_desktop_avatar_enabled(False)
            self.assertEqual(hud.avatar_scene, DEFAULT_AVATAR_SCENE)
        finally:
            hud.close()


if __name__ == "__main__":
    unittest.main()
