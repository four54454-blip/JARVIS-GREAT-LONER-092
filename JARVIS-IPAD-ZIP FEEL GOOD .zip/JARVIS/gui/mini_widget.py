"""Small, always-on-top launcher and live audio waveform."""
from __future__ import annotations

import math
import sys
from collections.abc import Callable

from PyQt6.QtCore import QPoint, QPointF, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen
from PyQt6.QtWidgets import QApplication, QWidget

from gui.style import px_font
from gui.theme import C


def enable_nonactivating_panel(widget: QWidget) -> None:
    app = QApplication.instance()
    if (sys.platform != "darwin" or app is None
            or app.platformName() != "cocoa"):
        return

    import AppKit
    import objc

    native_view = objc.objc_object(c_void_p=int(widget.winId()))
    panel = native_view.window()
    if panel is None or not panel.isKindOfClass_(AppKit.NSPanel):
        raise RuntimeError("The floating widget did not create a macOS panel.")

    style_mask = int(panel.styleMask())
    style_mask |= int(AppKit.NSWindowStyleMaskNonactivatingPanel)
    panel.setStyleMask_(style_mask)
    panel.setBecomesKeyOnlyIfNeeded_(True)


class MiniAssistantWidget(QWidget):
    open_settings = pyqtSignal()

    _SIZE = (136, 44)
    _BUTTON_WIDTH = 34
    _DRAG_THRESHOLD = 5

    def __init__(self, level_source: Callable[[], float]):
        flags = (
            Qt.WindowType.Tool
            | Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.WindowDoesNotAcceptFocus
        )
        super().__init__(None, flags)
        self._level_source = level_source
        self._level = 0.0
        self._phase = 0.0
        self._press_zone: str | None = None
        self._press_global = QPoint()
        self._drag_offset = QPoint()
        self._press_active = False
        self._dragged = False

        self.setFixedSize(*self._SIZE)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        if sys.platform == "darwin":
            self.setAttribute(Qt.WidgetAttribute.WA_MacAlwaysShowToolWindow)
            enable_nonactivating_panel(self)
        self.setToolTip("Drag to move · right: controls")
        self._timer = QTimer(self)
        self._timer.setInterval(33)
        self._timer.timeout.connect(self._tick)
        self._timer.start()

    def _tick(self) -> None:
        target = max(0.0, min(1.0, float(self._level_source())))
        self._level += (target - self._level) * 0.55
        if self._level > 0.015:
            self._phase = (self._phase + 0.72) % (2 * math.pi)
        self.update()

    def paintEvent(self, _event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        bounds = self.rect().adjusted(1, 1, -1, -1)
        background = QColor(C.BG)
        background.setAlpha(242)
        p.setPen(QPen(QColor(C.PRI), 1.2))
        p.setBrush(background)
        p.drawRoundedRect(bounds, 16, 16)

        button_w = self._BUTTON_WIDTH
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(C.PRI))
        for dx in (-2.5, 2.5):
            for dy in (-5.0, 0.0, 5.0):
                p.drawEllipse(
                    QPointF(button_w / 2 + 1 + dx, self.height() / 2 + dy),
                    1.2, 1.2,
                )

        cx = self.width() / 2
        cy = self.height() / 2
        half_span = (self.width() - 2 * button_w - 12) / 2
        wave = QPainterPath()
        samples = 27
        for i in range(samples):
            x = cx - half_span + 2 * half_span * i / (samples - 1)
            distance = abs((i / (samples - 1)) * 2 - 1)
            envelope = 0.20 + 0.80 * (1.0 - distance)
            amplitude = self._level * 8.0 * envelope
            y = cy + math.sin(self._phase + i * 0.72) * amplitude
            if i == 0:
                wave.moveTo(x, y)
            else:
                wave.lineTo(x, y)
        p.setPen(QPen(QColor(C.PRI), 1.8, Qt.PenStyle.SolidLine,
                      Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
        p.drawPath(wave)

        gear_x = self.width() - button_w / 2 - 1
        p.setPen(QPen(QColor(C.PRI), 1.3))
        p.drawEllipse(QPointF(gear_x, cy), 5, 5)
        p.setPen(QPen(QColor(C.PRI), 1.6, Qt.PenStyle.SolidLine,
                      Qt.PenCapStyle.RoundCap))
        for angle in range(0, 360, 60):
            radians = math.radians(angle)
            p.drawLine(
                QPointF(gear_x + math.cos(radians) * 6,
                        cy + math.sin(radians) * 6),
                QPointF(gear_x + math.cos(radians) * 8,
                        cy + math.sin(radians) * 8),
            )
        p.end()

    def mousePressEvent(self, event) -> None:
        if event.button() != Qt.MouseButton.LeftButton:
            event.ignore()
            return
        point = event.position().toPoint()
        self._press_global = event.globalPosition().toPoint()
        self._drag_offset = self._press_global - self.frameGeometry().topLeft()
        self._press_active = True
        if point.x() >= self.width() - self._BUTTON_WIDTH:
            self._press_zone = "settings"
        else:
            self._press_zone = None
        self._dragged = False
        event.accept()

    def mouseMoveEvent(self, event) -> None:
        if (not self._press_active
                or not (event.buttons() & Qt.MouseButton.LeftButton)):
            event.ignore()
            return
        self._move_for_drag(event.globalPosition().toPoint())
        event.accept()

    def _move_for_drag(self, current: QPoint) -> None:
        threshold = max(
            1, min(self._DRAG_THRESHOLD, QApplication.startDragDistance())
        )
        if (current - self._press_global).manhattanLength() < threshold:
            return

        self._dragged = True
        screen = QApplication.screenAt(current) or QApplication.primaryScreen()
        if screen is None:
            return
        available = screen.availableGeometry()
        position = current - self._drag_offset
        x = max(available.left(), min(
            position.x(), available.right() - self.width() + 1
        ))
        y = max(available.top(), min(
            position.y(), available.bottom() - self.height() + 1
        ))
        self.move(x, y)

    def mouseReleaseEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            if self._press_active:
                self._move_for_drag(event.globalPosition().toPoint())
            if self._press_active and not self._dragged:
                if self._press_zone == "settings":
                    self.open_settings.emit()
            self._press_active = False
            self._press_zone = None
            event.accept()
            return
        event.ignore()
