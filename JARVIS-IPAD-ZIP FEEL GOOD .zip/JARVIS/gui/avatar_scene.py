"""Shared procedural body rendering for the HUD and desktop avatar."""
from __future__ import annotations

from dataclasses import dataclass
from math import cos, pi, sin
from typing import TYPE_CHECKING, Any

from PyQt6.QtCore import QPointF, QRectF, Qt
from PyQt6.QtGui import (
    QBrush, QColor, QFont, QLinearGradient, QPainter, QPainterPath, QPen,
    QPolygonF, QRadialGradient,
)

from gui.style import px_font

if TYPE_CHECKING:
    from core.avatar import HoloAvatar


ENVIRONMENTS = (
    "classroom", "office", "laboratory", "workshop", "park", "city",
    "beach", "space", "custom", "current",
)
POSES = ("standing", "waving", "sitting", "walking")
PROP_SHAPES = (
    "cup", "book", "phone", "tablet", "ball", "flower", "lantern",
    "box", "sphere", "cylinder", "cone", "ring",
)
ELEMENT_SHAPES = (
    "panel", "box", "sphere", "cylinder", "cone", "ring", "tree",
    "desk", "chair", "window", "star",
)
ELEMENT_PLACEMENTS = (
    "back_left", "back_center", "back_right", "mid_left", "mid_right",
    "floor_left", "floor_right",
)
ELEMENT_SIZES = ("small", "medium", "large")


@dataclass(frozen=True)
class AvatarProp:
    shape: str
    hand: str
    label: str = ""


@dataclass(frozen=True)
class SceneElement:
    shape: str
    placement: str
    size: str = "medium"


@dataclass(frozen=True)
class AvatarScene:
    description: str = "Holographic studio"
    environment: str = "workshop"
    pose: str = "standing"
    props: tuple[AvatarProp, ...] = ()
    elements: tuple[SceneElement, ...] = ()


DEFAULT_AVATAR_SCENE = AvatarScene()


def _text(value: Any, limit: int) -> str:
    if not isinstance(value, str):
        return ""
    return " ".join(value.split())[:limit]


def _environment(value: Any) -> str:
    source = _text(value, 48).lower().replace("_", " ")
    raw = " ".join(
        "".join(char if char.isalnum() else " " for char in source).split()
    )
    if raw in ENVIRONMENTS:
        return raw
    groups = {
        "classroom": ("classroom", "class room", "school", "lecture"),
        "office": ("office", "meeting room", "workplace"),
        "laboratory": ("laboratory", "lab", "science"),
        "workshop": ("workshop", "studio", "factory"),
        "park": ("park", "forest", "garden", "woods"),
        "city": ("city", "street", "skyline"),
        "beach": ("beach", "ocean", "seaside", "shore"),
        "space": ("space", "spaceship", "galaxy", "orbit", "moon", "planet"),
    }
    for key, words in groups.items():
        if any(f" {word} " in f" {raw} " for word in words):
            return key
    return "custom"


def normalize_avatar_scene(data: Any) -> AvatarScene:
    """Validate model-produced scene data before it crosses into the HUD."""
    if isinstance(data, AvatarScene):
        return data
    if not isinstance(data, dict):
        raise ValueError("Scene data must be an object.")

    description = _text(
        data.get("description", data.get("scene_description", "")), 100
    )
    environment = _environment(data.get("environment", "workshop"))
    pose = _text(data.get("pose", "standing"), 20).lower()
    if pose not in POSES:
        raise ValueError(f"Unsupported avatar pose: {pose or '(empty)'}.")

    raw_props = data.get("props", [])
    if not isinstance(raw_props, (list, tuple)):
        raise ValueError("Scene props must be a list.")
    if len(raw_props) > 2:
        raise ValueError("A scene can place at most two props in the avatar's hands.")
    props: list[AvatarProp] = []
    for item in raw_props:
        if not isinstance(item, dict):
            raise ValueError("Each scene prop must be an object.")
        shape = _text(item.get("shape", ""), 24).lower()
        hand = _text(item.get("hand", ""), 24).lower()
        if shape not in PROP_SHAPES:
            raise ValueError(f"Unsupported prop shape: {shape or '(empty)'}.")
        if hand not in ("screen_left", "screen_right"):
            raise ValueError("Prop hand must be screen_left or screen_right.")
        label = _text(item.get("label", ""), 28) or shape
        props.append(AvatarProp(shape, hand, label))

    raw_elements = data.get("elements", [])
    if not isinstance(raw_elements, (list, tuple)):
        raise ValueError("Scene elements must be a list.")
    if len(raw_elements) > 6:
        raise ValueError("A scene can contain at most six set pieces.")
    elements: list[SceneElement] = []
    for item in raw_elements:
        if not isinstance(item, dict):
            raise ValueError("Each scene element must be an object.")
        shape = _text(item.get("shape", ""), 24).lower()
        placement = _text(item.get("placement", ""), 24).lower()
        size = _text(item.get("size", "medium"), 12).lower()
        if shape not in ELEMENT_SHAPES:
            raise ValueError(f"Unsupported scene element: {shape or '(empty)'}.")
        if placement not in ELEMENT_PLACEMENTS:
            raise ValueError(
                "Scene element placement must be a supported back, mid, or floor position."
            )
        if size not in ELEMENT_SIZES:
            raise ValueError(f"Unsupported scene element size: {size or '(empty)'}.")
        elements.append(SceneElement(shape, placement, size))

    return AvatarScene(description, environment, pose, tuple(props), tuple(elements))


def _alpha(color: QColor, opacity: float) -> QColor:
    result = QColor(color)
    result.setAlpha(max(0, min(255, round(255 * opacity))))
    return result


def _line(p: QPainter, color: QColor, opacity: float, width: float = 1.0) -> None:
    p.setPen(QPen(
        _alpha(color, opacity), width, Qt.PenStyle.SolidLine,
        Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin,
    ))


def _polygon(points: list[QPointF]) -> QPolygonF:
    return QPolygonF(points)


def _draw_box(p: QPainter, x: float, y: float, w: float, h: float,
              color: QColor, opacity: float) -> None:
    depth = min(w, h) * 0.22
    front = QRectF(x - w / 2, y - h / 2 + depth, w, h - depth)
    top = _polygon([
        QPointF(front.left(), front.top()),
        QPointF(x, front.top() - depth),
        QPointF(front.right(), front.top()),
        QPointF(front.right() - depth, front.top() + depth),
        QPointF(x - depth, front.top() + depth),
    ])
    _line(p, color, opacity, 1.2)
    p.setBrush(_alpha(color, opacity * 0.12))
    p.drawPolygon(top)
    p.drawRect(front)
    p.drawLine(QPointF(x, front.top() - depth), QPointF(x, front.bottom()))
    p.drawLine(QPointF(front.left(), front.top()), QPointF(x - depth, front.top() + depth))


def _draw_cylinder(p: QPainter, x: float, y: float, w: float, h: float,
                   color: QColor, opacity: float) -> None:
    top = y - h / 2
    bottom = y + h / 2
    cap = min(h * 0.22, w * 0.28)
    _line(p, color, opacity, 1.2)
    p.setBrush(_alpha(color, opacity * 0.10))
    p.drawEllipse(QRectF(x - w / 2, top, w, cap * 2))
    p.drawLine(QPointF(x - w / 2, top + cap), QPointF(x - w / 2, bottom - cap))
    p.drawLine(QPointF(x + w / 2, top + cap), QPointF(x + w / 2, bottom - cap))
    p.drawArc(QRectF(x - w / 2, bottom - cap, w, cap * 2), 0, 180 * 16)


def _draw_element(p: QPainter, rect: QRectF, element: SceneElement,
                  primary: QColor, accent: QColor) -> None:
    size_scale = {"small": 0.12, "medium": 0.19, "large": 0.26}[element.size]
    base = min(rect.width(), rect.height()) * size_scale
    x_map = {
        "back_left": rect.left() + rect.width() * 0.17,
        "back_center": rect.center().x(),
        "back_right": rect.right() - rect.width() * 0.17,
        "mid_left": rect.left() + rect.width() * 0.26,
        "mid_right": rect.right() - rect.width() * 0.26,
        "floor_left": rect.left() + rect.width() * 0.19,
        "floor_right": rect.right() - rect.width() * 0.19,
    }
    y_map = {
        "back_left": rect.top() + rect.height() * 0.39,
        "back_center": rect.top() + rect.height() * 0.36,
        "back_right": rect.top() + rect.height() * 0.39,
        "mid_left": rect.top() + rect.height() * 0.59,
        "mid_right": rect.top() + rect.height() * 0.59,
        "floor_left": rect.top() + rect.height() * 0.73,
        "floor_right": rect.top() + rect.height() * 0.73,
    }
    x, y = x_map[element.placement], y_map[element.placement]
    color = accent if element.shape in ("star", "sphere", "ring") else primary
    w, h = base * 1.15, base * 0.82
    _line(p, color, 0.45, 1.1)
    if element.shape in ("panel", "window"):
        p.setBrush(_alpha(color, 0.07))
        p.drawRect(QRectF(x - w / 2, y - h / 2, w, h))
        p.drawLine(QPointF(x, y - h / 2), QPointF(x, y + h / 2))
        p.drawLine(QPointF(x - w / 2, y), QPointF(x + w / 2, y))
    elif element.shape in ("box", "desk", "chair"):
        if element.shape == "desk":
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRect(QRectF(x - w / 2, y - h / 3, w, h * 0.20))
            p.drawLine(QPointF(x - w * 0.36, y - h * 0.13), QPointF(x - w * 0.36, y + h / 2))
            p.drawLine(QPointF(x + w * 0.36, y - h * 0.13), QPointF(x + w * 0.36, y + h / 2))
        elif element.shape == "chair":
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawLine(QPointF(x - w * 0.3, y), QPointF(x + w * 0.3, y))
            p.drawLine(QPointF(x - w * 0.3, y), QPointF(x - w * 0.3, y - h / 2))
            p.drawLine(QPointF(x - w * 0.3, y - h / 2), QPointF(x + w * 0.3, y - h / 2))
            p.drawLine(QPointF(x - w * 0.3, y), QPointF(x - w * 0.3, y + h / 2))
            p.drawLine(QPointF(x + w * 0.3, y), QPointF(x + w * 0.3, y + h / 2))
        else:
            _draw_box(p, x, y, w, h, color, 0.42)
    elif element.shape in ("sphere", "ring"):
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(QRectF(x - w / 2, y - h / 2, w, h))
        p.drawEllipse(QRectF(x - w * 0.22, y - h / 2, w * 0.44, h))
        p.drawLine(QPointF(x - w / 2, y), QPointF(x + w / 2, y))
    elif element.shape == "cylinder":
        _draw_cylinder(p, x, y, w * 0.68, h, color, 0.45)
    elif element.shape == "cone":
        p.setBrush(_alpha(color, 0.08))
        p.drawPolygon(_polygon([
            QPointF(x, y - h / 2), QPointF(x - w / 2, y + h / 2),
            QPointF(x + w / 2, y + h / 2),
        ]))
        p.drawEllipse(QRectF(x - w / 2, y + h * 0.35, w, h * 0.3))
    elif element.shape == "tree":
        p.setBrush(_alpha(color, 0.07))
        p.drawLine(QPointF(x, y + h / 2), QPointF(x, y - h * 0.05))
        p.drawPolygon(_polygon([
            QPointF(x, y - h / 2), QPointF(x - w / 2, y + h * 0.12),
            QPointF(x + w / 2, y + h * 0.12),
        ]))
        p.drawPolygon(_polygon([
            QPointF(x, y - h * 0.25), QPointF(x - w * 0.42, y + h * 0.30),
            QPointF(x + w * 0.42, y + h * 0.30),
        ]))
    elif element.shape == "star":
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawLine(QPointF(x - w / 2, y), QPointF(x + w / 2, y))
        p.drawLine(QPointF(x, y - h / 2), QPointF(x, y + h / 2))
        p.drawLine(QPointF(x - w * 0.3, y - h * 0.32), QPointF(x + w * 0.3, y + h * 0.32))
        p.drawLine(QPointF(x + w * 0.3, y - h * 0.32), QPointF(x - w * 0.3, y + h * 0.32))


def _draw_floor(p: QPainter, rect: QRectF, primary: QColor, horizon: float) -> None:
    cx = rect.center().x()
    _line(p, primary, 0.24, 1.0)
    for i in range(-9, 10):
        x = cx + i * rect.width() * 0.09
        p.drawLine(
            QPointF(cx + (x - cx) * 0.06, horizon),
            QPointF(x, rect.bottom()),
        )
    y = horizon
    gap = rect.height() * 0.035
    while y < rect.bottom():
        p.drawLine(QPointF(rect.left(), y), QPointF(rect.right(), y))
        y += gap
        gap *= 1.30


def _draw_environment(p: QPainter, rect: QRectF, environment: str,
                      primary: QColor, accent: QColor, background: QColor) -> None:
    cx, top, width, height = rect.center().x(), rect.top(), rect.width(), rect.height()
    horizon = top + height * 0.62
    gradient = QLinearGradient(rect.topLeft(), rect.bottomLeft())
    gradient.setColorAt(0.0, _alpha(primary, 0.12))
    gradient.setColorAt(0.52, _alpha(background, 0.96))
    gradient.setColorAt(1.0, _alpha(primary, 0.08))
    p.fillRect(rect, QBrush(gradient))
    glow = QRadialGradient(cx, top + height * 0.38, width * 0.60)
    glow.setColorAt(0.0, _alpha(primary, 0.11))
    glow.setColorAt(1.0, _alpha(background, 0.0))
    p.fillRect(rect, QBrush(glow))

    if environment == "classroom":
        board = QRectF(cx - width * 0.27, top + height * 0.13, width * 0.54, height * 0.23)
        p.setBrush(_alpha(primary, 0.06))
        _line(p, primary, 0.58, 1.4)
        p.drawRoundedRect(board, 4, 4)
        _line(p, accent, 0.50, 1.1)
        p.drawLine(QPointF(board.left() + board.width() * 0.12, board.center().y()),
                   QPointF(board.left() + board.width() * 0.62, board.center().y()))
        p.drawLine(QPointF(board.left() + board.width() * 0.12, board.center().y() + 6),
                   QPointF(board.left() + board.width() * 0.42, board.center().y() + 6))
        for side in (-1, 1):
            x = cx + side * width * 0.39
            window = QRectF(x - width * 0.075, top + height * 0.17,
                            width * 0.15, height * 0.24)
            _line(p, primary, 0.34, 1.0)
            p.drawRect(window)
            p.drawLine(QPointF(window.center().x(), window.top()),
                       QPointF(window.center().x(), window.bottom()))
            p.drawLine(QPointF(window.left(), window.center().y()),
                       QPointF(window.right(), window.center().y()))
            desk_y = horizon + height * 0.04
            p.drawLine(QPointF(x - width * 0.08, desk_y),
                       QPointF(x + width * 0.08, desk_y))
            p.drawLine(QPointF(x - width * 0.06, desk_y),
                       QPointF(x - width * 0.06, desk_y + height * 0.11))
            p.drawLine(QPointF(x + width * 0.06, desk_y),
                       QPointF(x + width * 0.06, desk_y + height * 0.11))
    elif environment in ("office", "laboratory", "workshop"):
        _line(p, primary, 0.30, 1.0)
        for side in (-1, 1):
            x = cx + side * width * 0.34
            cabinet = QRectF(x - width * 0.10, top + height * 0.17,
                             width * 0.20, height * 0.36)
            p.setBrush(_alpha(primary, 0.035))
            p.drawRect(cabinet)
            for row in (0.25, 0.50, 0.75):
                p.drawLine(QPointF(cabinet.left(), cabinet.top() + cabinet.height() * row),
                           QPointF(cabinet.right(), cabinet.top() + cabinet.height() * row))
        bench_y = horizon + height * 0.05
        p.drawLine(QPointF(cx - width * 0.40, bench_y),
                   QPointF(cx + width * 0.40, bench_y))
        p.drawLine(QPointF(cx - width * 0.34, bench_y),
                   QPointF(cx - width * 0.34, bench_y + height * 0.14))
        p.drawLine(QPointF(cx + width * 0.34, bench_y),
                   QPointF(cx + width * 0.34, bench_y + height * 0.14))
        if environment == "office":
            window = QRectF(cx - width * 0.22, top + height * 0.13,
                            width * 0.44, height * 0.28)
            p.drawRect(window)
            p.drawLine(QPointF(cx, window.top()), QPointF(cx, window.bottom()))
            p.drawLine(QPointF(window.left(), window.center().y()),
                       QPointF(window.right(), window.center().y()))
        else:
            for side in (-1, 1):
                x = cx + side * width * 0.34
                p.drawEllipse(QPointF(x, top + height * 0.26), 5, 5)
    elif environment == "city":
        _line(p, primary, 0.30, 1.0)
        for i, factor in enumerate((-0.42, -0.27, 0.27, 0.42)):
            bw = width * (0.10 if i % 2 else 0.13)
            bh = height * (0.18 + (i % 3) * 0.07)
            bx = cx + width * factor
            building = QRectF(bx - bw / 2, horizon - bh, bw, bh)
            p.setBrush(_alpha(primary, 0.04))
            p.drawRect(building)
            for row in range(2):
                for col in (-1, 1):
                    p.drawRect(QRectF(bx + col * bw * 0.20 - 2,
                                      building.top() + 5 + row * 8, 3, 4))
    elif environment == "park":
        hill = QPainterPath()
        hill.moveTo(rect.left(), horizon + height * 0.08)
        hill.cubicTo(cx - width * 0.28, horizon - height * 0.04,
                     cx + width * 0.12, horizon + height * 0.14,
                     rect.right(), horizon + height * 0.02)
        _line(p, primary, 0.42, 1.4)
        p.setBrush(_alpha(primary, 0.06))
        hill.lineTo(rect.right(), rect.bottom())
        hill.lineTo(rect.left(), rect.bottom())
        hill.closeSubpath()
        p.drawPath(hill)
        for x in (rect.left() + width * 0.15, rect.right() - width * 0.15):
            p.drawLine(QPointF(x, horizon + height * 0.14),
                       QPointF(x, horizon - height * 0.09))
            p.drawEllipse(QRectF(x - 11, horizon - height * 0.19, 22, 22))
            p.drawEllipse(QRectF(x - 18, horizon - height * 0.12, 36, 22))
    elif environment == "beach":
        sun_y = top + height * 0.27
        _line(p, accent, 0.55, 1.3)
        p.drawEllipse(QPointF(cx + width * 0.27, sun_y), height * 0.065, height * 0.065)
        _line(p, primary, 0.40, 1.0)
        p.drawLine(QPointF(rect.left(), horizon), QPointF(rect.right(), horizon))
        for row in range(3):
            y = horizon + height * (0.05 + row * 0.06)
            p.drawArc(QRectF(cx - width * (0.22 + row * 0.06), y - 4,
                             width * (0.44 + row * 0.12), 10), 0, 180 * 16)
    elif environment == "space":
        rnd = ((0.12, 0.17), (0.23, 0.34), (0.81, 0.24), (0.76, 0.48),
               (0.19, 0.54), (0.88, 0.13), (0.32, 0.12), (0.68, 0.34))
        _line(p, accent, 0.72, 1.0)
        for ix, iy in rnd:
            p.drawEllipse(QPointF(rect.left() + width * ix, top + height * iy), 1.5, 1.5)
        planet = QRectF(rect.right() - width * 0.26, top + height * 0.14,
                        width * 0.16, width * 0.16)
        p.setBrush(_alpha(primary, 0.07))
        p.drawEllipse(planet)
        p.drawEllipse(QRectF(planet.left() - 8, planet.center().y() - 6,
                             planet.width() + 16, 12))
    else:
        _line(p, primary, 0.28, 1.0)
        for side in (-1, 1):
            x = cx + side * width * 0.36
            p.drawPolygon(_polygon([
                QPointF(x - width * 0.10, horizon),
                QPointF(x - width * 0.08, top + height * 0.25),
                QPointF(x + width * 0.08, top + height * 0.25),
                QPointF(x + width * 0.10, horizon),
            ]))
            p.drawLine(QPointF(x - width * 0.07, top + height * 0.32),
                       QPointF(x + width * 0.07, top + height * 0.32))
            p.drawLine(QPointF(x - width * 0.07, top + height * 0.40),
                       QPointF(x + width * 0.07, top + height * 0.40))

    _draw_floor(p, rect, primary, horizon)


def _draw_bone(p: QPainter, start: QPointF, end: QPointF,
               primary: QColor, accent: QColor, width: float) -> None:
    dx, dy = end.x() - start.x(), end.y() - start.y()
    length = max(1.0, (dx * dx + dy * dy) ** 0.5)
    nx, ny = -dy / length, dx / length
    half = width * 0.78
    path = QPainterPath()
    path.moveTo(start.x() + nx * half, start.y() + ny * half)
    path.lineTo(end.x() + nx * half * 0.72, end.y() + ny * half * 0.72)
    path.quadTo(end.x(), end.y(), end.x() - nx * half * 0.72, end.y() - ny * half * 0.72)
    path.lineTo(start.x() - nx * half, start.y() - ny * half)
    path.quadTo(start.x(), start.y(), start.x() + nx * half, start.y() + ny * half)
    path.closeSubpath()
    bounds = path.boundingRect()
    gradient = QLinearGradient(bounds.topLeft(), bounds.topRight())
    gradient.setColorAt(0.0, _alpha(primary.darker(320), 0.98))
    gradient.setColorAt(0.22, _alpha(primary.darker(155), 0.99))
    gradient.setColorAt(0.52, _alpha(primary.lighter(145), 0.99))
    gradient.setColorAt(0.82, _alpha(primary.darker(135), 0.99))
    gradient.setColorAt(1.0, _alpha(primary.darker(290), 0.98))
    p.setBrush(QBrush(gradient))
    _line(p, primary.lighter(165), 0.68, max(0.85, width * 0.10))
    p.drawPath(path)
    p.setBrush(Qt.BrushStyle.NoBrush)
    _line(p, accent.lighter(125), 0.24, max(0.7, width * 0.07))
    p.drawLine(
        QPointF(start.x() + nx * half * 0.34, start.y() + ny * half * 0.34),
        QPointF(end.x() + nx * half * 0.24, end.y() + ny * half * 0.24),
    )
    p.save()
    p.setClipPath(path)
    _line(p, primary.darker(260), 0.34, max(0.65, width * 0.045))
    for fraction in (0.24, 0.50, 0.76):
        x = start.x() + dx * fraction
        y = start.y() + dy * fraction
        mesh_half = half * (1.0 - 0.28 * fraction)
        p.drawLine(QPointF(x + nx * mesh_half, y + ny * mesh_half),
                   QPointF(x - nx * mesh_half, y - ny * mesh_half))
    for side in (-1.0, 1.0):
        p.drawLine(
            QPointF(start.x() + nx * half * side * 0.58,
                    start.y() + ny * half * side * 0.58),
            QPointF(end.x() - nx * half * side * 0.46,
                    end.y() - ny * half * side * 0.46),
        )
    p.drawLine(
        QPointF(start.x() - nx * half * 0.55, start.y() - ny * half * 0.55),
        QPointF(end.x() + nx * half * 0.42, end.y() + ny * half * 0.42),
    )
    p.restore()
    for point in (start, end):
        joint_radius = half * 0.46
        joint = QRadialGradient(
            point.x() - joint_radius * 0.25,
            point.y() - joint_radius * 0.32, joint_radius * 1.15
        )
        joint.setColorAt(0.0, _alpha(primary.lighter(185), 1.0))
        joint.setColorAt(0.55, _alpha(primary, 0.98))
        joint.setColorAt(1.0, _alpha(primary.darker(260), 0.98))
        p.setBrush(QBrush(joint))
        _line(p, primary.lighter(165), 0.58, max(0.7, joint_radius * 0.14))
        p.drawEllipse(QRectF(point.x() - joint_radius, point.y() - joint_radius,
                             joint_radius * 2, joint_radius * 2))
    p.setBrush(Qt.BrushStyle.NoBrush)


def _draw_hand(p: QPainter, wrist: QPointF, side: int, head_h: float,
               primary: QColor, waving: bool = False) -> None:
    center_y = wrist.y() + (-1 if waving else 1) * head_h * 0.10
    palm = QRectF(
        wrist.x() - head_h * 0.095,
        center_y - head_h * 0.11,
        head_h * 0.19,
        head_h * 0.22,
    )
    gradient = QLinearGradient(palm.topLeft(), palm.bottomRight())
    gradient.setColorAt(0.0, _alpha(primary.lighter(155), 0.92))
    gradient.setColorAt(0.55, _alpha(primary, 0.96))
    gradient.setColorAt(1.0, _alpha(primary.darker(210), 0.96))
    p.setBrush(QBrush(gradient))
    _line(p, primary.lighter(165), 0.64, 0.8)
    p.drawRoundedRect(palm, head_h * 0.08, head_h * 0.08)
    p.setBrush(Qt.BrushStyle.NoBrush)

    direction = -1 if waving else 1
    _line(p, primary.lighter(185), 0.48, max(0.65, head_h * 0.012))
    for finger in (-1, 0, 1):
        x = wrist.x() + finger * head_h * 0.052
        start = QPointF(x, center_y + direction * head_h * 0.075)
        end = QPointF(
            x + finger * head_h * 0.016,
            center_y + direction * head_h * (0.24 if finger == 0 else 0.20),
        )
        p.drawLine(start, end)
    thumb_start = QPointF(
        palm.left() if side < 0 else palm.right(),
        center_y + direction * head_h * 0.015,
    )
    thumb_end = QPointF(
        thumb_start.x() + side * head_h * 0.12,
        center_y + direction * head_h * 0.10,
    )
    p.drawLine(thumb_start, thumb_end)


def _draw_foot(p: QPainter, ankle: QPointF, toe: QPointF, side: int,
               head_h: float, primary: QColor) -> None:
    heel_x = ankle.x() - side * head_h * 0.045
    left = min(heel_x, toe.x()) - head_h * 0.035
    right = max(heel_x, toe.x()) + head_h * 0.035
    top = min(ankle.y(), toe.y()) - head_h * 0.06
    foot = QRectF(left, top, max(head_h * 0.22, right - left), head_h * 0.13)
    gradient = QLinearGradient(foot.topLeft(), foot.bottomRight())
    gradient.setColorAt(0.0, _alpha(primary.lighter(155), 0.94))
    gradient.setColorAt(0.52, _alpha(primary, 0.98))
    gradient.setColorAt(1.0, _alpha(primary.darker(220), 0.97))
    p.setBrush(QBrush(gradient))
    _line(p, primary.lighter(165), 0.66, 0.8)
    p.drawRoundedRect(foot, head_h * 0.065, head_h * 0.065)
    p.setBrush(Qt.BrushStyle.NoBrush)
    _line(p, primary.darker(230), 0.34, 0.65)
    p.drawLine(QPointF(foot.left() + foot.width() * 0.36, foot.center().y()),
               QPointF(foot.right() - foot.width() * 0.08, foot.center().y()))


def _draw_prop(p: QPainter, point: QPointF, shape: str, label: str, scale: float,
               primary: QColor, accent: QColor, opacity: float) -> None:
    p.save()
    p.setOpacity(max(0.0, min(1.0, opacity)))
    x, y = point.x(), point.y() - scale * 0.28
    w, h = scale * 0.58, scale * 0.78
    color = accent if shape in ("flower", "ball", "sphere", "ring") else primary
    _line(p, color, 0.88, max(1.0, scale * 0.045))
    p.setBrush(_alpha(color, 0.14))

    if shape == "cup":
        top, bottom = y - h / 2, y + h / 2
        p.drawEllipse(QRectF(x - w / 2, top, w, h * 0.16))
        p.drawLine(QPointF(x - w / 2, top + h * 0.08),
                   QPointF(x - w * 0.36, bottom - h * 0.08))
        p.drawLine(QPointF(x + w / 2, top + h * 0.08),
                   QPointF(x + w * 0.36, bottom - h * 0.08))
        p.drawArc(QRectF(x - w * 0.36, bottom - h * 0.17,
                         w * 0.72, h * 0.16), 180 * 16, 180 * 16)
        p.drawEllipse(QRectF(x + w * 0.32, y - h * 0.16, w * 0.48, h * 0.38))
    elif shape == "book":
        rect = QRectF(x - w / 2, y - h / 2, w, h)
        p.drawRoundedRect(rect, 1.5, 1.5)
        p.drawLine(QPointF(x, rect.top()), QPointF(x, rect.bottom()))
        p.drawLine(QPointF(x - w * 0.37, y - h * 0.15),
                   QPointF(x - w * 0.08, y - h * 0.15))
        p.drawLine(QPointF(x + w * 0.08, y - h * 0.15),
                   QPointF(x + w * 0.36, y - h * 0.15))
    elif shape in ("phone", "tablet"):
        factor = 1.0 if shape == "phone" else 1.45
        rect = QRectF(x - w * factor / 2, y - h / 2, w * factor, h)
        p.drawRoundedRect(rect, 3, 3)
        p.drawRect(rect.adjusted(2, 3, -2, -4))
        p.drawEllipse(QPointF(x, rect.bottom() - 2), 0.7, 0.7)
    elif shape in ("ball", "sphere", "ring"):
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(QRectF(x - w / 2, y - h / 2, w, h))
        p.drawEllipse(QRectF(x - w * 0.22, y - h / 2, w * 0.44, h))
        p.drawLine(QPointF(x - w / 2, y), QPointF(x + w / 2, y))
    elif shape == "flower":
        p.drawLine(QPointF(x, y + h / 2), QPointF(x, y - h * 0.04))
        p.drawEllipse(QPointF(x, y - h * 0.18), w * 0.14, w * 0.14)
        for angle in range(0, 360, 72):
            dx, dy = cos(angle * 3.14159 / 180), sin(angle * 3.14159 / 180)
            p.drawEllipse(QPointF(x + dx * w * 0.19, y - h * 0.18 + dy * w * 0.19),
                          w * 0.13, w * 0.13)
    elif shape == "lantern":
        p.drawRoundedRect(QRectF(x - w * 0.36, y - h * 0.38, w * 0.72, h * 0.68), 2, 2)
        p.drawArc(QRectF(x - w * 0.20, y - h * 0.56, w * 0.40, h * 0.40),
                  0, 180 * 16)
        p.drawLine(QPointF(x - w * 0.22, y - h * 0.15),
                   QPointF(x + w * 0.22, y - h * 0.15))
    elif shape in ("cylinder", "cone"):
        if shape == "cylinder":
            _draw_cylinder(p, x, y, w, h, color, 0.9)
        else:
            p.drawPolygon(_polygon([
                QPointF(x, y - h / 2), QPointF(x - w / 2, y + h / 2),
                QPointF(x + w / 2, y + h / 2),
            ]))
            p.drawEllipse(QRectF(x - w / 2, y + h * 0.34, w, h * 0.28))
    else:
        _draw_box(p, x, y, w, h, color, 0.9)
    if label:
        p.setFont(px_font(6, QFont.Weight.DemiBold))
        _line(p, color, 0.76, 1.0)
        p.drawText(
            QRectF(x - scale * 0.58, y + h * 0.54, scale * 1.16, 8),
            Qt.AlignmentFlag.AlignCenter,
            label[:18].upper(),
        )
    p.restore()


def _draw_body(p: QPainter, rect: QRectF, avatar: HoloAvatar,
               scene: AvatarScene, primary: QColor, accent: QColor,
               now: float, amplitude: float, speaking: bool,
               materialize: float, width_limit: float = 0.62,
               travel_fraction: float = 0.18) -> None:
    body_h = min(rect.height() * 0.91, rect.width() * width_limit)
    if body_h < 70:
        return
    head_h = body_h / 6.4
    walking = scene.pose == "walking"
    walk_phase = now * 2 * pi * 0.95 if walking else 0.0
    walk_sway = sin(walk_phase) * head_h * 0.025 if walking else 0.0
    travel = (
        sin(now * 0.65) * rect.width() * travel_fraction if walking else 0.0
    )
    cx = rect.center().x() + sin(now * 0.72) * body_h * 0.006 + travel + walk_sway
    floor_y = rect.bottom() - body_h * 0.025
    walk_bob = max(0.0, sin(walk_phase * 2)) * body_h * 0.006 if walking else 0.0
    top = floor_y - body_h - walk_bob
    head_r = head_h / max(0.5, avatar.SPAN)
    head_cy = top + head_r
    breath = sin(now * 1.3) * body_h * 0.004

    shoulder_y = top + body_h * 0.18 + breath
    shoulder_half = head_h * 0.90
    waist_y = top + body_h * 0.49
    hip_y = top + body_h * 0.61
    hip_half = head_h * 0.56
    leg_width = max(2.3, head_h * 0.27)
    arm_width = max(2.3, head_h * 0.22)
    hand_props = {prop.hand: prop for prop in scene.props}
    hand_points: dict[str, QPointF] = {}

    if scene.pose == "sitting":
        seat_y = hip_y + body_h * 0.05
        _line(p, primary, 0.42, 1.2)
        p.drawLine(QPointF(cx - head_h * 0.70, seat_y),
                   QPointF(cx + head_h * 0.70, seat_y))
        p.drawLine(QPointF(cx - head_h * 0.60, seat_y),
                   QPointF(cx - head_h * 0.60, floor_y - body_h * 0.08))
        p.drawLine(QPointF(cx + head_h * 0.60, seat_y),
                   QPointF(cx + head_h * 0.60, floor_y - body_h * 0.08))

    for side in (-1, 1):
        hip = QPointF(cx + side * hip_half * 0.56, hip_y)
        if scene.pose == "sitting":
            knee = QPointF(cx + side * head_h * 0.92, hip_y + body_h * 0.10)
            ankle = QPointF(knee.x(), floor_y - body_h * 0.04)
            stride = 0.0
        elif walking:
            leg_phase = walk_phase + (pi if side > 0 else 0.0)
            stride = cos(leg_phase)
            lift = max(0.0, sin(leg_phase)) * head_h * 0.24
            knee = QPointF(
                cx + side * head_h * 0.38 + stride * head_h * 0.12,
                top + body_h * 0.80 - lift * 0.34,
            )
            ankle = QPointF(
                cx + side * head_h * 0.50 + stride * head_h * 0.25,
                floor_y - body_h * 0.02 - lift,
            )
        else:
            knee = QPointF(cx + side * head_h * 0.36, top + body_h * 0.80)
            ankle = QPointF(cx + side * head_h * 0.43, floor_y - body_h * 0.02)
            stride = 0.0
        _draw_bone(p, hip, knee, primary, accent, leg_width)
        _draw_bone(p, knee, ankle, primary, accent, leg_width)
        _line(p, primary, 0.68, 1.5)
        foot_y = ankle.y() + body_h * 0.02
        toe_lift = (
            max(0.0, sin(leg_phase)) * head_h * 0.06
            if walking else 0.0
        )
        p.drawLine(
            ankle,
            QPointF(
                ankle.x() + side * head_h * 0.24 + stride * head_h * 0.08,
                foot_y - toe_lift,
            ),
        )
        _draw_foot(
            p, ankle,
            QPointF(
                ankle.x() + side * head_h * 0.24 + stride * head_h * 0.08,
                foot_y - toe_lift,
            ),
            side, head_h, primary,
        )
        _line(p, accent, 0.56, 1.0)
        p.drawEllipse(hip, leg_width * 0.40, leg_width * 0.40)
        p.drawEllipse(knee, leg_width * 0.40, leg_width * 0.40)

    neck_top = top + head_h * 0.68
    neck_bottom = shoulder_y + head_h * 0.14
    neck = QPainterPath()
    neck.moveTo(cx - head_h * 0.18, neck_top)
    neck.cubicTo(cx - head_h * 0.20, neck_top + head_h * 0.24,
                 cx - head_h * 0.24, neck_bottom - head_h * 0.10,
                 cx - head_h * 0.40, neck_bottom)
    neck.lineTo(cx + head_h * 0.40, neck_bottom)
    neck.cubicTo(cx + head_h * 0.24, neck_bottom - head_h * 0.10,
                 cx + head_h * 0.20, neck_top + head_h * 0.24,
                 cx + head_h * 0.18, neck_top)
    neck.closeSubpath()
    neck_gradient = QLinearGradient(
        QPointF(cx - head_h * 0.22, neck_top),
        QPointF(cx + head_h * 0.22, neck_top),
    )
    neck_gradient.setColorAt(0.0, _alpha(primary.darker(260), 0.98))
    neck_gradient.setColorAt(0.42, _alpha(primary.lighter(145), 0.98))
    neck_gradient.setColorAt(1.0, _alpha(primary.darker(280), 0.98))
    p.setBrush(QBrush(neck_gradient))
    _line(p, primary.lighter(160), 0.62, 1.2)
    p.drawPath(neck)
    p.save()
    p.setClipPath(neck)
    _line(p, primary.darker(260), 0.30, 0.65)
    p.drawLine(QPointF(cx - head_h * 0.08, neck_top + head_h * 0.08),
               QPointF(cx + head_h * 0.10, neck_bottom - head_h * 0.06))
    p.drawLine(QPointF(cx + head_h * 0.08, neck_top + head_h * 0.10),
               QPointF(cx - head_h * 0.10, neck_bottom - head_h * 0.08))
    p.restore()

    torso_left = cx - shoulder_half
    torso_right = cx + shoulder_half
    shoulder = shoulder_y
    torso = QPainterPath()
    torso.moveTo(torso_left, shoulder)
    torso.cubicTo(cx - shoulder_half * 0.82, shoulder + head_h * 0.45,
                  cx - hip_half * 1.15, waist_y - head_h * 0.35,
                  cx - hip_half, hip_y)
    pelvis_y = hip_y + head_h * 0.16
    torso.cubicTo(cx - hip_half * 0.94, hip_y + head_h * 0.11,
                  cx - head_h * 0.22, pelvis_y, cx, pelvis_y)
    torso.cubicTo(cx + head_h * 0.22, pelvis_y,
                  cx + hip_half * 0.94, hip_y + head_h * 0.11,
                  cx + hip_half, hip_y)
    torso.cubicTo(cx + hip_half * 1.15, waist_y - head_h * 0.35,
                  cx + shoulder_half * 0.82, shoulder + head_h * 0.45,
                  torso_right, shoulder)
    torso.closeSubpath()
    torso_gradient = QLinearGradient(
        QPointF(torso_left, shoulder), QPointF(torso_right, hip_y)
    )
    torso_gradient.setColorAt(0.0, _alpha(primary.darker(250), 0.98))
    torso_gradient.setColorAt(0.22, _alpha(primary.lighter(142), 0.99))
    torso_gradient.setColorAt(0.50, _alpha(primary.lighter(112), 0.99))
    torso_gradient.setColorAt(0.78, _alpha(primary.darker(135), 0.99))
    torso_gradient.setColorAt(1.0, _alpha(primary.darker(260), 0.98))
    p.setBrush(QBrush(torso_gradient))
    _line(p, primary.lighter(170), 0.92, 1.6)
    p.drawPath(torso)

    p.save()
    p.setClipPath(torso)
    _line(p, primary.darker(250), 0.34, 0.70)
    mesh_rows = (0.12, 0.30, 0.48, 0.66, 0.84, 0.98)
    mesh_columns = (0.0, 0.25, 0.50, 0.75, 1.0)
    for row in mesh_rows:
        y = shoulder + (pelvis_y - shoulder) * row
        p.drawLine(QPointF(torso_left, y), QPointF(torso_right, y))
    for column in mesh_columns[1:-1]:
        x = torso_left + (torso_right - torso_left) * column
        p.drawLine(QPointF(x, shoulder), QPointF(x, pelvis_y))
    for row in range(len(mesh_rows) - 1):
        y0 = shoulder + (pelvis_y - shoulder) * mesh_rows[row]
        y1 = shoulder + (pelvis_y - shoulder) * mesh_rows[row + 1]
        for column in range(len(mesh_columns) - 1):
            x0 = torso_left + (torso_right - torso_left) * mesh_columns[column]
            x1 = torso_left + (torso_right - torso_left) * mesh_columns[column + 1]
            if (row + column) % 2:
                p.drawLine(QPointF(x0, y0), QPointF(x1, y1))
            else:
                p.drawLine(QPointF(x1, y0), QPointF(x0, y1))
    p.restore()

    for side in (-1, 1):
        cap_x = cx + side * shoulder_half * 0.80
        cap = QRectF(cap_x - head_h * 0.21, shoulder_y - head_h * 0.04,
                     head_h * 0.42, head_h * 0.38)
        cap_gradient = QRadialGradient(
            cap.center().x() - side * head_h * 0.08,
            cap.center().y() - head_h * 0.12, head_h * 0.42,
        )
        cap_gradient.setColorAt(0.0, _alpha(primary.lighter(180), 0.96))
        cap_gradient.setColorAt(0.48, _alpha(primary.lighter(115), 0.97))
        cap_gradient.setColorAt(1.0, _alpha(primary.darker(240), 0.98))
        p.setBrush(QBrush(cap_gradient))
        _line(p, primary.lighter(170), 0.66, 0.9)
        p.drawEllipse(cap)

    if speaking and amplitude > 0.02:
        _line(p, accent, min(0.50, amplitude * 0.75), 1.2)
        p.drawLine(QPointF(cx - head_h * 0.27, shoulder_y + head_h * 0.12),
                   QPointF(cx + head_h * 0.27, shoulder_y + head_h * 0.12))

    for side, hand in ((-1, "screen_left"), (1, "screen_right")):
        shoulder_point = QPointF(cx + side * shoulder_half * 0.94, shoulder_y + breath)
        if hand in hand_props:
            elbow = QPointF(cx + side * shoulder_half * 1.30,
                            shoulder_y + head_h * 0.56)
            wrist = QPointF(cx + side * shoulder_half * 1.30,
                            shoulder_y + head_h * 1.18)
        elif scene.pose == "waving" and side == 1:
            elbow = QPointF(cx + side * shoulder_half * 1.32,
                            shoulder_y - head_h * 0.10)
            wrist = QPointF(cx + side * shoulder_half * 1.34,
                            shoulder_y - head_h * 0.76)
        elif walking:
            arm_phase = walk_phase + (0.0 if side > 0 else pi)
            swing = cos(arm_phase) * head_h * 0.30
            elbow = QPointF(
                cx + side * shoulder_half * 1.22 + swing * 0.28,
                shoulder_y + body_h * 0.16 + sin(arm_phase) * head_h * 0.06,
            )
            wrist = QPointF(
                cx + side * shoulder_half * 1.08 + swing,
                hip_y + head_h * 0.11 + sin(arm_phase + 0.3) * head_h * 0.08,
            )
        else:
            elbow = QPointF(cx + side * shoulder_half * 1.25,
                            shoulder_y + body_h * 0.17)
            wrist = QPointF(cx + side * shoulder_half * 1.10,
                            hip_y + head_h * 0.12)
        _draw_bone(p, shoulder_point, elbow, primary, accent, arm_width)
        _draw_bone(p, elbow, wrist, primary, accent, arm_width)
        _line(p, primary, 0.58, 1.0)
        p.drawEllipse(elbow, arm_width * 0.40, arm_width * 0.40)
        p.drawEllipse(wrist, arm_width * 0.50, arm_width * 0.50)
        _draw_hand(
            p, wrist, side, head_h, primary,
            waving=scene.pose == "waving" and side == 1 and hand not in hand_props,
        )
        hand_points[hand] = wrist
        if scene.pose == "waving" and side == 1 and hand not in hand_props:
            _line(p, primary, 0.68, 1.0)
            for finger in (-2, -1, 0, 1, 2):
                p.drawLine(
                    wrist,
                    QPointF(wrist.x() + finger * head_h * 0.08,
                            wrist.y() - head_h * (0.18 + 0.02 * (2 - abs(finger)))),
                )

    for hand, prop in hand_props.items():
        point = hand_points[hand]
        prop_scale = head_h * 0.92
        _draw_prop(
            p, point, prop.shape, prop.label, prop_scale, primary, accent,
            materialize,
        )
        if materialize < 1.0:
            ring = prop_scale * (0.45 + 0.75 * materialize)
            _line(p, accent, (1.0 - materialize) * 0.62, 1.0)
            p.drawEllipse(QRectF(point.x() - ring, point.y() - ring,
                                 ring * 2, ring * 2))

    avatar.paint(p, cx, head_cy, head_r, primary, accent, QColor(0, 6, 10))


def paint_avatar_scene(p: QPainter, rect: QRectF, avatar: HoloAvatar,
                       scene: AvatarScene, primary: QColor, accent: QColor,
                       background: QColor, now: float, amplitude: float,
                       speaking: bool, materialize: float = 1.0) -> None:
    """Paint a local, model-directed holographic environment and full figure."""
    p.save()
    p.setClipRect(rect)
    _draw_environment(p, rect, scene.environment, primary, accent, background)
    for element in scene.elements:
        _draw_element(p, rect, element, primary, accent)

    title = scene.description or scene.environment.replace("_", " ").title()
    p.setFont(px_font(9, QFont.Weight.DemiBold, spacing=1.1))
    _line(p, primary, 0.70, 1.0)
    p.drawText(
        QRectF(rect.left() + 10, rect.top() + 7, rect.width() - 20, 15),
        Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
        title[:52].upper(),
    )
    _draw_body(
        p, rect, avatar, scene, primary, accent, now, amplitude, speaking,
        max(0.0, min(1.0, materialize)),
    )
    p.restore()


def paint_avatar_figure(p: QPainter, rect: QRectF, avatar: HoloAvatar,
                        scene: AvatarScene, primary: QColor, accent: QColor,
                        now: float, amplitude: float, speaking: bool) -> None:
    """Paint only the full-body figure for a transparent desktop overlay."""
    p.save()
    p.setClipRect(rect)
    _draw_body(
        p, rect, avatar, scene, primary, accent, now, amplitude, speaking,
        materialize=1.0, width_limit=0.95, travel_fraction=0.0,
    )
    p.restore()
