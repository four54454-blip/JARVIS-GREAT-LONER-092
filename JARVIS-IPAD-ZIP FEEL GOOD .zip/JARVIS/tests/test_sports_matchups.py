import unittest
from pathlib import Path
from unittest.mock import Mock, patch

import requests

import actions.web_search as web_search


class SportsSearchTests(unittest.TestCase):
    def test_sports_research_requests_one_evidence_based_forecast(self):
        with patch.object(
            web_search, "_gemini_search", return_value="Team A is favored."
        ) as search:
            result = web_search._sports("Team A versus Team B")

        query = search.call_args.args[0]
        self.assertIn("current-season strength", query)
        self.assertIn("opponent quality", query)
        self.assertIn("single winner", query)
        self.assertIn("Normalize all possible outcomes to 100%", query)
        self.assertEqual(result, "Team A is favored.")

    def test_sports_mode_routes_to_matchup_research(self):
        with patch.object(
            web_search, "_sports", return_value="fixture evidence"
        ) as sports:
            result = web_search.web_search({
                "query": "Lions versus Bears today",
                "mode": "sports",
            })

        sports.assert_called_once_with("Lions versus Bears today")
        self.assertIn("fixture evidence", result)

    def test_sports_mode_passes_known_league(self):
        with patch.object(
            web_search, "_sports", return_value="fixture evidence"
        ) as sports:
            web_search.web_search({
                "query": "Lakers versus Celtics",
                "mode": "sports",
                "league": "nba",
            })

        sports.assert_called_once_with("Lakers versus Celtics", "nba")

    def test_scores_mode_routes_to_score_lookup(self):
        with patch.object(
            web_search, "_live_scores", return_value="scoreboard"
        ) as scores:
            result = web_search.web_search({
                "query": "Lakers score now",
                "mode": "scores",
                "league": "nba",
            })

        scores.assert_called_once_with("Lakers score now", "nba")
        self.assertIn("scoreboard", result)

    def test_live_scoreboard_formats_score_status_time_and_source(self):
        response = Mock()
        response.json.return_value = {
            "events": [{
                "date": "2026-11-25T02:00:00Z",
                "competitions": [{
                    "status": {"type": {"state": "in", "shortDetail": "4th quarter"}},
                    "competitors": [
                        {
                            "homeAway": "away",
                            "team": {"displayName": "Chicago Bulls"},
                            "score": "101",
                        },
                        {
                            "homeAway": "home",
                            "team": {"displayName": "New York Knicks"},
                            "score": "98",
                        },
                    ],
                }],
            }, {
                "date": "2026-11-25T00:00:00Z",
                "competitions": [{
                    "status": {"type": {"state": "post", "shortDetail": "Final"}},
                    "competitors": [
                        {
                            "homeAway": "away",
                            "team": {"displayName": "Detroit Pistons"},
                            "score": "104",
                        },
                        {
                            "homeAway": "home",
                            "team": {"displayName": "Orlando Magic"},
                            "score": "86",
                        },
                    ],
                }],
            }],
        }
        with patch("requests.get", return_value=response) as get:
            result = web_search._espn_scoreboard("nba")

        get.assert_called_once_with(
            "https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard?limit=100",
            timeout=(2, 4),
        )
        response.raise_for_status.assert_called_once_with()
        self.assertIn("retrieved ", result)
        self.assertIn("UTC", result)
        self.assertIn("LIVE - 4th quarter", result)
        self.assertIn("Chicago Bulls 101 at New York Knicks 98", result)
        self.assertIn("FINAL | Detroit Pistons 104 at Orlando Magic 86", result)
        self.assertNotIn("FINAL - Final", result)
        self.assertIn("Source: https://site.api.espn.com/", result)

    def test_scores_mode_uses_web_search_if_scoreboard_is_unavailable(self):
        with (
            patch.object(web_search, "_espn_scoreboard", return_value=None),
            patch.object(web_search, "_search", return_value="web fallback") as search,
        ):
            result = web_search._live_scores("Lakers score now", "nba")

        search.assert_called_once_with("nba Lakers score now live sports scores today")
        self.assertEqual(result, "web fallback")

    def test_score_lookup_falls_back_when_espn_request_is_offline(self):
        with (
            patch("requests.get", side_effect=requests.Timeout("offline")),
            patch.object(web_search, "_search", return_value="web fallback") as search,
        ):
            result = web_search._live_scores("Lakers score now", "nba")

        search.assert_called_once_with("nba Lakers score now live sports scores today")
        self.assertEqual(result, "web fallback")

    def test_score_lookup_falls_back_for_unsupported_league(self):
        with (
            patch("requests.get") as get,
            patch.object(web_search, "_search", return_value="web fallback") as search,
        ):
            result = web_search._live_scores("score now", "rugby")

        get.assert_not_called()
        search.assert_called_once_with("rugby score now live sports scores today")
        self.assertEqual(result, "web fallback")

    def test_sports_forecast_includes_current_scoreboard_snapshot(self):
        with (
            patch.object(
                web_search, "_espn_scoreboard",
                return_value="ESPN snapshot retrieved 12:00 UTC",
            ),
            patch.object(
                web_search, "_gemini_search", return_value="Forecast evidence."
            ) as search,
        ):
            result = web_search._sports("Lakers versus Celtics", "nba")

        self.assertIn("ESPN snapshot retrieved 12:00 UTC", search.call_args.args[0])
        self.assertEqual(result, "Forecast evidence.")

    def test_sports_search_falls_back_to_multiple_current_sources(self):
        responses = [
            [{"title": "Schedule", "snippet": "Today's fixture", "url": "https://a"}],
            [{"title": "Form", "snippet": "Recent results", "url": "https://b"}],
            [{"title": "Team news", "snippet": "Lineup update", "url": "https://c"}],
        ]
        with (
            patch.object(web_search, "_gemini_search", side_effect=RuntimeError("offline")),
            patch.object(web_search, "_ddg_search", side_effect=responses) as search,
        ):
            result = web_search._sports("Lions versus Bears today")

        self.assertEqual(search.call_count, 3)
        self.assertIn("Today's fixture", result)
        self.assertIn("Recent results", result)
        self.assertIn("Lineup update", result)


class PromptBehaviorTests(unittest.TestCase):
    def test_informational_and_sports_prompt_directs_immediate_answers(self):
        prompt = (
            Path(__file__).resolve().parents[1] / "core" / "prompt.txt"
        ).read_text(encoding="utf-8")

        self.assertIn("do not ask permission to search or", prompt)
        self.assertIn('web_search mode="scores"', prompt)
        self.assertIn(
            "clarifying question only when an essential detail cannot be inferred",
            prompt,
        )


if __name__ == "__main__":
    unittest.main()
