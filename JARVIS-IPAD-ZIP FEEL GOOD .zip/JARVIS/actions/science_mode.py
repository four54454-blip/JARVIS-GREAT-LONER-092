from __future__ import annotations

from core import science_mode as state


def _show_workspace(player, current) -> None:
    if player and hasattr(player, "show_science_workspace"):
        player.show_science_workspace(
            current.active,
            current.experiment,
            current.materials,
            current.available_materials,
            current.steps,
            current.completed_steps,
            bool(player.camera_stream_active()),
        )


def science_mode(parameters: dict, player=None) -> str:
    args = dict(parameters or {})
    action = str(args.get("action") or "").strip().lower()
    plan_error = ""

    if action in ("start", "enable", "on"):
        experiment = str(args.get("experiment") or "").strip()
        try:
            plan = state.generate_plan(experiment) if experiment else None
        except Exception as exc:
            plan = None
            plan_error = str(exc)[:160]
        current = state.start(
            experiment,
            materials=plan["materials"] if plan else (),
            steps=plan["steps"] if plan else (),
        )
        if plan:
            message = (
                "Science Mode is active. The science workspace is open with a "
                "bounded low-risk plan. Check off materials by telling me which "
                "ones you have, or tapping them in the workspace. I will guide "
                "the listed steps one at a time. This plan is not a safety "
                "guarantee.\nMaterials needed: "
                + ", ".join(plan["materials"])
                + "\nProcedure:\n"
                + "\n".join(
                    f"{index}. {step}"
                    for index, step in enumerate(plan["steps"], start=1)
                )
            )
        elif experiment:
            message = (
                "Science Mode is active and focused on science. "
                + (
                    "The plan request failed; "
                    if plan_error else "I could not "
                )
                + "produce a safe step-by-step plan for that topic, so I have not "
                "invented materials or steps. I can discuss its scientific "
                "principles; use an established, qualified protocol for any "
                "hands-on work."
            )
        else:
            message = (
                "Science Mode is active and focused on science. Tell me the "
                "experiment or question to build a safe, bounded plan."
            )
        if player and not player.camera_stream_active():
            message += (
                " Camera checks are paused until you open the live preview; "
                "I will not turn it on automatically."
            )
    elif action in ("update", "progress"):
        material_change = "material" in args
        if material_change:
            current = state.set_material_available(
                str(args.get("material") or ""),
                bool(args.get("have_material", True)),
            )
            if "completed_step" in args:
                current = state.update(completed_step=args.get("completed_step"))
        else:
            current = state.update(completed_step=args.get("completed_step"))
        if not current.active:
            message = "Science Mode is off; start it before updating the experiment."
        else:
            parts = []
            if material_change:
                status = (
                    "available"
                    if str(args.get("material") or "").casefold()
                    in {item.casefold() for item in current.available_materials}
                    else "not available"
                )
                parts.append(
                    f"Material checklist updated: {args.get('material')} is {status}."
                )
            if "completed_step" in args:
                if current.steps and current.completed_steps < len(current.steps):
                    parts.append(
                        f"Next: step {current.completed_steps + 1}: "
                        f"{current.steps[current.completed_steps]}"
                    )
                elif current.steps:
                    parts.append("All listed steps are marked complete. Review the observations.")
                else:
                    parts.append("No procedure is listed to advance.")
            if not parts:
                parts.append("No materials or step progress was provided to update.")
            message = " ".join(parts)
    elif action in ("stop", "disable", "off", "end"):
        current = state.stop()
        message = "Science Mode is off. The camera preview, if open, remains on."
    else:
        message = "Choose Science Mode action start, update, or stop."
        current = state.snapshot()

    _show_workspace(player, current)
    if player:
        player.write_log(f"SYS: {message}")
        if action in ("start", "enable", "on") and plan_error:
            player.write_log(f"ERR: Science plan generation failed: {plan_error}")
    return message


TOOL = {
    "name": "science_mode",
    "description": (
        "Start or stop Science Mode on a clear request. On start, include the "
        "experiment/topic and any user-provided protocol context; the action "
        "will generate a bounded low-risk plan when one is appropriate. Use "
        "action='update' with material and have_material to record one "
        "checklist item the user explicitly says they have or lack, or "
        "completed_step to record the count of steps they explicitly completed. "
        "A changed experiment must "
        "start a fresh plan; never invent replacement steps in an update. "
        "Never mark materials available or steps complete unless the user said so. Starting does "
        "not open the camera. The open preview is sampled about every 10 "
        "seconds, without recording video. Science Mode has no status action."
    ),
    "tier": "core",
    "brief": "Enable/disable science focus, materials, procedure and observation.",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "enum": ["start", "update", "stop"],
                "description": "Start, update experiment progress, or stop.",
            },
            "experiment": {
                "type": "STRING",
                "description": "The user's experiment or science topic.",
            },
            "material": {
                "type": "STRING",
                "description": "Exact name of one checklist material discussed by the user.",
            },
            "have_material": {
                "type": "BOOLEAN",
                "description": "True if the user says they have it; false if they lack it.",
            },
            "completed_step": {
                "type": "INTEGER",
                "description": "Count of sequential steps the user completed.",
            },
        },
        "required": ["action"],
    },
    "handler": science_mode,
}
