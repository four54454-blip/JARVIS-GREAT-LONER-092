import asyncio
import threading
import time
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

import actions.computer_control as computer_control
from main import (
    JarvisLive,
    TOOL_DECLARATIONS,
    _is_stock_cursor_move_request,
    _remote_tool_block_reason,
    _stock_cursor_tool_block_reason,
    _work_mode_intent,
)
from providers.schema import CORE_TOOLS, budget


class StockCursorIntentTests(unittest.TestCase):
    def test_remote_sessions_cannot_access_system_or_network_tools(self):
        self.assertIsNotNone(_remote_tool_block_reason(
            "system_status", {}, remote_request=True
        ))
        self.assertIsNotNone(_remote_tool_block_reason(
            "computer_settings", {"action": "toggle_wifi"}, remote_request=True
        ))
        self.assertIsNone(_remote_tool_block_reason(
            "computer_settings", {"action": "volume_set"}, remote_request=True
        ))
        self.assertIsNone(_remote_tool_block_reason(
            "system_status", {}, remote_request=False
        ))

    def test_remote_tool_context_expires_and_local_input_clears_it(self):
        jarvis = JarvisLive.__new__(JarvisLive)
        jarvis._remote_request_expires_at = 0.0
        jarvis._remote_request_lock = threading.Lock()

        jarvis._remote_request_expires_at = time.monotonic() - 1
        self.assertFalse(jarvis._is_remote_request_active())
        jarvis._set_remote_request(True)
        self.assertTrue(jarvis._is_remote_request_active())
        jarvis._set_remote_request(False)
        self.assertFalse(jarvis._is_remote_request_active())

    def test_natural_cursor_requests_are_recognized(self):
        requests = (
            "Okay then move my cursor to where I should buy.",
            "Point the mouse at the AAPL limit-price box.",
            "Put the pointer on the order-entry price field.",
            "Hover over the AAPL price entry.",
            "Don't click anything, just move my cursor to the price field.",
        )
        for request in requests:
            with self.subTest(request=request):
                self.assertTrue(_is_stock_cursor_move_request(request))

    def test_questions_negation_and_unrelated_pointer_moves_are_rejected(self):
        non_requests = (
            "Should I buy AAPL?",
            "Do not move my cursor to the buy field.",
            "What if you moved the mouse to the price field?",
            "Move my cursor to the desktop.",
        )
        for request in non_requests:
            with self.subTest(request=request):
                self.assertFalse(_is_stock_cursor_move_request(request))

    def test_only_the_dedicated_action_is_allowed_for_stock_cursor_requests(self):
        text = "Move my cursor to the AAPL price entry so I can buy."
        self.assertIsNone(_stock_cursor_tool_block_reason(
            "move_cursor_to_stock_entry", {"ticker": "AAPL"}, text
        ))
        self.assertIsNotNone(_stock_cursor_tool_block_reason(
            "computer_control", {"action": "move_to_stock_entry"}, text
        ))
        self.assertIsNotNone(_stock_cursor_tool_block_reason(
            "computer_control", {"action": "click"}, text
        ))
        self.assertIsNotNone(_stock_cursor_tool_block_reason(
            "browser_control", {"action": "smart_click"}, text
        ))
        self.assertIsNotNone(_stock_cursor_tool_block_reason(
            "move_cursor_to_stock_entry", {"ticker": "AAPL"},
            "Should I buy AAPL?",
        ))

    def test_financial_order_requests_cannot_trigger_clicks(self):
        self.assertIsNotNone(_stock_cursor_tool_block_reason(
            "computer_control",
            {"action": "screen_click"},
            "Buy 5 shares of AAPL.",
        ))

    def test_typed_request_survives_cleared_transcript_buffer_for_tool_guard(self):
        jarvis = JarvisLive.__new__(JarvisLive)
        jarvis._tool_request_text = ""
        jarvis._tool_request_text_expires_at = 0.0
        jarvis._tool_request_text_lock = threading.Lock()
        jarvis._remember_tool_request_text(
            "Move my cursor to the AAPL price entry."
        )

        current_text = jarvis._current_tool_request_text("")

        self.assertTrue(_is_stock_cursor_move_request(current_text))
        self.assertIsNone(_stock_cursor_tool_block_reason(
            "move_cursor_to_stock_entry", {"ticker": "AAPL"}, current_text
        ))
        jarvis._tool_request_text_expires_at = 0.0
        self.assertEqual(jarvis._current_tool_request_text(""), "")
        jarvis._remember_tool_request_text("Move my cursor to the AAPL price entry.")
        jarvis._remember_tool_request_text("Tell me about the weather.")
        self.assertEqual(jarvis._current_tool_request_text(""), "")

    def test_work_mode_only_changes_on_clear_direct_intent(self):
        self.assertEqual(_work_mode_intent("Hey Jarvis, initiate work mode."), "on")
        self.assertEqual(_work_mode_intent("Please exit work mode."), "off")
        self.assertEqual(
            _work_mode_intent("Could you please initiate work mode?"), "on"
        )
        self.assertEqual(
            _work_mode_intent("Can you please exit work mode?"), "off"
        )
        for request in (
            "What does work mode do?",
            "Can you make a work mode feature?",
            "If work mode is active, continue.",
            "Don't start work mode.",
            "Don't stop work mode.",
            "Don't turn work mode off.",
            'The note says "start work mode".',
        ):
            with self.subTest(request=request):
                self.assertIsNone(_work_mode_intent(request))

    def test_work_mode_state_switches_style_and_is_reversible(self):
        jarvis = JarvisLive.__new__(JarvisLive)
        jarvis._work_mode_active = False
        jarvis._work_mode_lock = threading.Lock()
        jarvis.ui = Mock()

        jarvis._set_work_mode(True)
        self.assertTrue(jarvis._is_work_mode_active())
        jarvis.ui.set_face_emotion.assert_called_once_with("calm")

        jarvis._set_work_mode(False)
        self.assertFalse(jarvis._is_work_mode_active())
        jarvis.ui.set_face_emotion.assert_called_with("neutral")


class StockCursorActionTests(unittest.TestCase):
    def test_action_moves_only_to_visible_price_entry_for_valid_ticker(self):
        with (
            patch.object(computer_control, "_require_pyautogui"),
            patch.object(
                computer_control, "_screen_find", return_value=(420, 275)
            ) as screen_find,
            patch.object(computer_control, "pyautogui") as mouse,
        ):
            mouse.size.return_value = (1000, 800)
            result = computer_control._move_to_stock_entry("NASDAQ:AAPL")

        self.assertIn("Cursor moved to the visible price-entry field for AAPL", result)
        self.assertIn("Nothing was clicked, typed, or submitted", result)
        self.assertIn("AAPL", screen_find.call_args.args[0])
        mouse.moveTo.assert_called_once_with(420, 275, duration=0.3)
        mouse.click.assert_not_called()
        mouse.typewrite.assert_not_called()
        mouse.hotkey.assert_not_called()

    def test_action_can_infer_one_active_stock_when_ticker_is_omitted(self):
        with (
            patch.object(computer_control, "_require_pyautogui"),
            patch.object(
                computer_control, "_screen_find", return_value=(420, 275)
            ) as screen_find,
            patch.object(computer_control, "pyautogui") as mouse,
        ):
            mouse.size.return_value = (1000, 800)
            result = computer_control._move_to_stock_entry("")

        self.assertIn("clearly identified active stock", result)
        self.assertIn(
            "one clearly identifiable active stock",
            screen_find.call_args.args[0],
        )
        mouse.moveTo.assert_called_once_with(420, 275, duration=0.3)

    def test_missing_or_out_of_bounds_target_never_moves_pointer(self):
        with (
            patch.object(computer_control, "_require_pyautogui"),
            patch.object(computer_control, "_screen_find", return_value=None),
            patch.object(computer_control, "pyautogui") as mouse,
        ):
            result = computer_control._move_to_stock_entry("AAPL")
        self.assertIn("Cursor not moved", result)
        mouse.moveTo.assert_not_called()

        with (
            patch.object(computer_control, "_require_pyautogui"),
            patch.object(
                computer_control, "_screen_find", return_value=(1000, 800)
            ),
            patch.object(computer_control, "pyautogui") as mouse,
        ):
            mouse.size.return_value = (1000, 800)
            result = computer_control._move_to_stock_entry("AAPL")
        self.assertIn("outside the screen", result)
        mouse.moveTo.assert_not_called()

    def test_invalid_ticker_is_rejected_before_screen_capture(self):
        with (
            patch.object(computer_control, "_screen_find") as screen_find,
            patch.object(computer_control, "pyautogui") as mouse,
        ):
            result = computer_control._move_to_stock_entry("AAPL\nsubmit")

        self.assertIn("valid stock ticker", result)
        screen_find.assert_not_called()
        mouse.size.assert_not_called()

    def test_pointer_tool_is_separately_declared_and_kept_in_small_model_budget(self):
        declaration = next(
            tool for tool in TOOL_DECLARATIONS
            if tool["name"] == "move_cursor_to_stock_entry"
        )
        self.assertEqual(declaration["parameters"]["required"], [])
        self.assertIn("move_cursor_to_stock_entry", CORE_TOOLS)
        selected = budget(
            TOOL_DECLARATIONS + [computer_control.TOOL], max_tools=8
        )
        self.assertIn(
            "move_cursor_to_stock_entry",
            [tool["name"] for tool in selected],
        )
        self.assertNotIn(
            "move_to_stock_entry",
            computer_control.TOOL["parameters"]["properties"]["action"]["description"],
        )

    def test_inline_tool_dispatches_through_worker_thread_action_registry(self):
        jarvis = JarvisLive.__new__(JarvisLive)
        jarvis._lock_mode_active = False
        jarvis._has_lock_mode_authorization = Mock(return_value=False)
        jarvis._self_destructing = False
        jarvis._remote_request_expires_at = 0.0
        jarvis._remote_request_lock = threading.Lock()
        jarvis.ui = Mock(muted=False)
        jarvis.speak = Mock()
        jarvis._action_registry = Mock()
        jarvis._action_registry.has.return_value = True
        jarvis._action_registry.run.return_value = (
            "Cursor moved to the visible price-entry field for AAPL."
        )
        jarvis._action_registry.scheduling.return_value = None
        jarvis._plugin_registry = Mock()
        jarvis._plugin_registry.scheduling.return_value = None
        call = SimpleNamespace(
            id="cursor-call",
            name="move_cursor_to_stock_entry",
            args={"ticker": "AAPL"},
        )

        response = asyncio.run(jarvis._execute_tool(call))

        self.assertIn("Cursor moved", response.response["result"])
        jarvis._action_registry.run.assert_called_once()
        call_args = jarvis._action_registry.run.call_args.args
        self.assertEqual(call_args[0], "computer_control")
        self.assertEqual(call_args[1], {
            "action": "move_to_stock_entry",
            "ticker": "AAPL",
        })

    def test_remote_system_status_tool_is_blocked_before_execution(self):
        jarvis = JarvisLive.__new__(JarvisLive)
        jarvis._lock_mode_active = False
        jarvis._has_lock_mode_authorization = Mock(return_value=False)
        jarvis._self_destructing = False
        jarvis._remote_request_expires_at = time.monotonic() + 60
        jarvis._remote_request_lock = threading.Lock()
        jarvis.ui = Mock()
        call = SimpleNamespace(id="status-call", name="system_status", args={})

        response = asyncio.run(jarvis._execute_tool(call))

        self.assertIn("unavailable in remote sessions", response.response["result"])
        jarvis.ui.write_log.assert_called_once()


if __name__ == "__main__":
    unittest.main()
