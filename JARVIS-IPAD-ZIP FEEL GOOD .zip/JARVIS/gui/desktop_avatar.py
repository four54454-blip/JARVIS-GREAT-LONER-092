"""Draggable, transparent desktop projection of the live JARVIS avatar."""
from __future__ import annotations

import sys
import time

from PyQt6.QtCore import QPoint, QPointF, QRectF, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QPainter, QPen, QRadialGradient
from PyQt6.QtWidgets import QApplication, QWidget

from gui.mini_widget import enable_nonactivating_panel
from gui.style import px_font
from gui.theme import C


class DesktopAvatarOverlay(QWidget):
    close_requested = pyqtSignal()

    _SIZE = (460, 620)
    _DRAG_THRESHOLD = 5
    _CLOSE_SIZE = 38
    _WALK_SPEED = 72.0

    def __init__(self, hud):
        flags = (
            Qt.WindowType.Tool
            | Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.WindowDoesNotAcceptFocus
        )
        super().__init__(None, flags)
        self._hud = hud
        self._press_global = QPoint()
        self._drag_offset = QPoint()
        self._press_active = False
        self._close_pressed = False
        self._dragged = False
        self._walk_direction = 1
        self._walk_active = False
        self._last_tick = time.monotonic()

        self.setFixedSize(*self._SIZE)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setToolTip(
            "Drag to move · walking pose travels across this display · close at upper right"
        )
        self.setWindowTitle("JARVIS Desktop Avatar")

        self._timer = QTimer(self)
        self._timer.setInterval(33)
        self._timer.timeout.connect(self._tick)

        if sys.platform == "darwin":
            self.setAttribute(Qt.WidgetAttribute.WA_MacAlwaysShowToolWindow)
            self._configure_macos_spaces()

        screen = QApplication.primaryScreen()
        if screen is not None:
            area = screen.availableGeometry()
            scale = min(
                1.0,
                area.width() * 0.45 / self.width(),
                area.height() * 0.75 / self.height(),
            )
            if scale < 1.0:
                self.setFixedSize(
                    round(self.width() * scale),
                    round(self.height() * scale),
                )
            self.move(
                area.right() - self.width() - 28,
                max(area.top(), area.center().y() - self.height() // 2),
            )

    def _configure_macos_spaces(self) -> None:
        app = QApplication.instance()
        if app is None or app.platformName() != "cocoa":
            return
        try:
            enable_nonactivating_panel(self)
            import AppKit
            import objc

            native_view = objc.objc_object(c_void_p=int(self.winId()))
            panel = native_view.window()
            behavior = (
                int(AppKit.NSWindowCollectionBehaviorCanJoinAllSpaces)
                | int(AppKit.NSWindowCollectionBehaviorFullScreenAuxiliary)
            )
            panel.setCollectionBehavior_(behavior)
        except (AttributeError, ImportError, RuntimeError) as exc:
            print(f"[Avatar] Desktop overlay space behavior unavailable: {exc}")

    def showEvent(self, event) -> None:
        super().showEvent(event)
        self._last_tick = time.monotonic()
        self._timer.start()

    def hideEvent(self, event) -> None:
        self._timer.stop()
        super().hideEvent(event)

    def _tick(self) -> None:
        now = time.monotonic()
        elapsed = min(0.1, max(0.0, now - self._last_tick))
        self._last_tick = now
        if self._hud.avatar_scene.pose == "walking":
            if not self._walk_active:
                screen = QApplication.screenAt(self.frameGeometry().center())
                screen = screen or QApplication.primaryScreen()
                if screen is not None:
                    self._walk_direction = (
                        1 if self.x() < screen.availableGeometry().center().x()
                        else -1
                    )
                self._walk_active = True
            self._walk_step(elapsed)
        else:
            self._walk_active = False
        self.update()

    def _walk_step(self, elapsed: float) -> None:
        screen = QApplication.screenAt(self.frameGeometry().center())
        screen = screen or QApplication.primaryScreen()
        if screen is None:
            return
        area = screen.availableGeometry()
        left = area.left()
        right = area.right() - self.width() + 1
        if right <= left:
            self.move(left, max(area.top(), min(self.y(), area.bottom())))
            return

        x = self.x() + self._walk_direction * self._WALK_SPEED * elapsed
        if x >= right:
            x = right
            self._walk_direction = -1
        elif x <= left:
            x = left
            self._walk_direction = 1
        y = max(area.top(), min(self.y(), area.bottom() - self.height() + 1))
        self.move(round(x), y)

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        center = QPointF(self.width() / 2, self.height() * 0.53)
        glow = QColor(C.PRI)
        glow.setAlpha(32)
        clear = QColor(C.PRI)
        clear.setAlpha(0)
        gradient = QRadialGradient(center, self.height() * 0.48)
        gradient.setColorAt(0.0, glow)
        gradient.setColorAt(1.0, clear)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(gradient)
        painter.drawEllipse(
            QRectF(16, 30, self.width() - 32, self.height() - 48)
        )

        self._hud.paint_desktop_avatar(
            painter,
            QRectF(16, 14, self.width() - 32, self.height() - 28),
        )

        painter.setPen(QPen(QColor(C.PRI).lighter(130), 1.0))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        for dx in (-5.0, 0.0, 5.0):
            painter.drawEllipse(QPointF(self.width() / 2 + dx, 15), 1.2, 1.2)

        close_rect = QRectF(
            self.width() - self._CLOSE_SIZE,
            0,
            self._CLOSE_SIZE,
            self._CLOSE_SIZE,
        )
        close_color = QColor(C.PRI)
        close_color.setAlpha(90)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(close_color)
        painter.drawEllipse(close_rect.adjusted(8, 8, -8, -8))
        painter.setPen(QPen(QColor(C.TEXT), 1.4))
        painter.setFont(px_font(15, QFont.Weight.Medium))
        painter.drawText(close_rect, Qt.AlignmentFlag.AlignCenter, "×")

    def mousePressEvent(self, event) -> None:
        if event.button() != Qt.MouseButton.LeftButton:
            event.ignore()
            return
        point = event.position().toPoint()
        self._press_global = event.globalPosition().toPoint()
        self._drag_offset = (
            self._press_global - self.frameGeometry().topLeft()
        )
        self._press_active = True
        self._close_pressed = (
            point.x() >= self.width() - self._CLOSE_SIZE
            and point.y() <= self._CLOSE_SIZE
        )
        self._dragged = False
        event.accept()

    def mouseMoveEvent(self, event) -> None:
        if (
            not self._press_active
            or not (event.buttons() & Qt.MouseButton.LeftButton)
        ):
            event.ignore()
            return
        self._move_for_drag(event.globalPosition().toPoint())
        event.accept()

    def _move_for_drag(self, current: QPoint) -> None:
        threshold = max(
            1, min(self._DRAG_THRESHOLD, QApplication.startDragDistance())
        )
        if (current - self._press_global).manhattanLength() < threshold:
            return
        self._dragged = True
        screen = QApplication.screenAt(current) or QApplication.primaryScreen()
        if screen is None:
            return
        area = screen.availableGeometry()
        position = current - self._drag_offset
        x = max(area.left(), min(
            position.x(), area.right() - self.width() + 1
        ))
        y = max(area.top(), min(
            position.y(), area.bottom() - self.height() + 1
        ))
        self.move(x, y)

    def mouseReleaseEvent(self, event) -> None:
        if event.button() != Qt.MouseButton.LeftButton:
            event.ignore()
            return
        if self._press_active:
            self._move_for_drag(event.globalPosition().toPoint())
        if self._press_active and self._close_pressed and not self._dragged:
            self.close_requested.emit()
        self._press_active = False
        self._close_pressed = False
        event.accept()
