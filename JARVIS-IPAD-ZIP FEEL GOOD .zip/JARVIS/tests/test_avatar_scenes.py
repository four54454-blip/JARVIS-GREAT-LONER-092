import unittest
from unittest.mock import patch

from PyQt6.QtCore import QRectF
from PyQt6.QtGui import QColor, QImage, QPainter

from gui.avatar_scene import (
    AvatarProp,
    DEFAULT_AVATAR_SCENE,
    _draw_body,
    normalize_avatar_scene,
    paint_avatar_figure,
)
from main import TOOL_DECLARATIONS
from memory import config_manager
from providers.schema import CORE_TOOLS, budget, to_openai


class AvatarSceneTests(unittest.TestCase):
    def test_classroom_scene_can_add_a_cup_to_a_specific_hand(self):
        scene = normalize_avatar_scene({
            "scene_description": "JARVIS in a blue plated classroom",
            "environment": "classroom",
            "pose": "standing",
            "props": [{"shape": "cup", "hand": "screen_right"}],
        })

        self.assertEqual(scene.environment, "classroom")
        self.assertEqual(scene.pose, "standing")
        self.assertEqual(scene.props, (AvatarProp("cup", "screen_right", "cup"),))

    def test_prop_only_scene_keeps_current_environment(self):
        scene = normalize_avatar_scene({
            "environment": "current",
            "pose": "waving",
            "props": [{"shape": "book", "hand": "screen_left"}],
        })

        self.assertEqual(scene.environment, "current")
        self.assertEqual(scene.description, "")
        self.assertEqual(scene.props[0].shape, "book")

    def test_freeform_setting_uses_safe_custom_backdrop(self):
        scene = normalize_avatar_scene({
            "description": "A glass castle above a blue ocean",
            "environment": "a glass castle in the clouds",
            "pose": "sitting",
            "elements": [
                {"shape": "box", "placement": "back_left", "size": "large"},
                {"shape": "cone", "placement": "back_right"},
            ],
        })

        self.assertEqual(scene.environment, "custom")
        self.assertEqual(len(scene.elements), 2)
        self.assertEqual(scene.elements[1].size, "medium")

    def test_walking_pose_moves_and_animates_the_full_body(self):
        scene = normalize_avatar_scene({"pose": "walking"})

        class Head:
            SPAN = 2.2

            def paint(self, *_args):
                pass

        def render_at(now):
            image = QImage(480, 560, QImage.Format.Format_ARGB32)
            image.fill(QColor("#00060a"))
            painter = QPainter(image)
            _draw_body(
                painter, QRectF(0, 0, 480, 560), Head(), scene,
                QColor("#00bfff"), QColor("#65e5ff"),
                now, 0.0, False, 1.0,
            )
            painter.end()
            return image

        first, later = render_at(0.0), render_at(1.7)
        changed_pixels = sum(
            first.pixel(x, y) != later.pixel(x, y)
            for y in range(first.height())
            for x in range(first.width())
        )
        self.assertGreater(changed_pixels, 1000)

    def test_desktop_figure_keeps_the_overlay_background_transparent(self):
        from core.avatar import HoloAvatar

        image = QImage(480, 560, QImage.Format.Format_ARGB32)
        image.fill(QColor(0, 0, 0, 0))
        painter = QPainter(image)
        paint_avatar_figure(
            painter, QRectF(0, 0, 480, 560), HoloAvatar(),
            DEFAULT_AVATAR_SCENE, QColor("#00bfff"), QColor("#65e5ff"),
            1.0, 0.0, False,
        )
        painter.end()

        self.assertEqual(image.pixelColor(0, 0).alpha(), 0)
        visible_pixels = sum(
            image.pixelColor(x, y).alpha() > 0
            for y in range(image.height())
            for x in range(image.width())
        )
        self.assertGreater(visible_pixels, 500)
        self.assertTrue(all(
            any(image.pixelColor(x, y).alpha() > 0 for x in range(235, 246))
            for y in range(135, 180)
        ))

    def test_invalid_or_unbounded_scene_objects_are_rejected(self):
        with self.assertRaisesRegex(ValueError, "Unsupported prop shape"):
            normalize_avatar_scene({
                "props": [{"shape": "run arbitrary code", "hand": "screen_right"}],
            })
        with self.assertRaisesRegex(ValueError, "at most two props"):
            normalize_avatar_scene({
                "props": [
                    {"shape": "cup", "hand": "screen_left"},
                    {"shape": "book", "hand": "screen_right"},
                    {"shape": "ball", "hand": "screen_left"},
                ],
            })

    def test_scene_tool_is_kept_in_small_model_core_budget(self):
        self.assertIn("set_avatar_scene", CORE_TOOLS)
        tool = next(
            item for item in TOOL_DECLARATIONS
            if item.get("name") == "set_avatar_scene"
        )
        selected = budget(TOOL_DECLARATIONS, max_tools=8)
        self.assertIn("scene_description", tool["parameters"]["properties"])
        self.assertIn("set_avatar_scene", [item["name"] for item in selected])
        self.assertIn(
            "walking",
            tool["parameters"]["properties"]["pose"]["enum"],
        )
        converted = next(
            item["function"] for item in to_openai([tool])
            if item["function"]["name"] == "set_avatar_scene"
        )
        self.assertEqual(
            converted["parameters"]["properties"]["props"]["items"]["properties"]
            ["shape"]["enum"][0],
            "cup",
        )


class AvatarBodySettingTests(unittest.TestCase):
    def test_body_mode_defaults_off_and_persists_through_config_helper(self):
        with patch.object(config_manager, "load_api_keys", return_value={}):
            self.assertFalse(config_manager.get_avatar_body_enabled())

        with patch.object(
            config_manager, "load_api_keys",
            return_value={"avatar_body_enabled": True},
        ):
            self.assertTrue(config_manager.get_avatar_body_enabled())

        with patch.object(config_manager, "_save_flag") as save_flag:
            config_manager.save_avatar_body_enabled(True)
        save_flag.assert_called_once_with("avatar_body_enabled", True)

    def test_desktop_avatar_setting_defaults_off_and_persists(self):
        with patch.object(config_manager, "load_api_keys", return_value={}):
            self.assertFalse(config_manager.get_desktop_avatar_enabled())

        with patch.object(
            config_manager, "load_api_keys",
            return_value={"desktop_avatar_enabled": True},
        ):
            self.assertTrue(config_manager.get_desktop_avatar_enabled())

        with patch.object(config_manager, "_save_flag") as save_flag:
            config_manager.save_desktop_avatar_enabled(True)
        save_flag.assert_called_once_with("desktop_avatar_enabled", True)


if __name__ == "__main__":
    unittest.main()
