import asyncio
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

from fastapi.testclient import TestClient

from dashboard.server import DashboardServer


class DashboardPwaTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.root = Path(self.temp_dir.name)
        self.server = DashboardServer()
        self.server._uploads_dir = self.root / "uploads"
        self.server._uploads_dir.mkdir()
        self.server._tokens["test-token"] = time.time()
        self.client = TestClient(self.server.app)
        self.headers = {"Authorization": "Bearer test-token"}

    def tearDown(self):
        self.client.close()
        self.temp_dir.cleanup()

    def test_pwa_shell_assets_are_served(self):
        manifest = self.client.get("/manifest.webmanifest")
        worker = self.client.get("/service-worker.js")
        icon = self.client.get("/icons/jarvis.svg")
        png_icon = self.client.get("/icons/jarvis-192.png")

        self.assertEqual(manifest.status_code, 200)
        manifest_data = manifest.json()
        self.assertEqual(manifest_data["display"], "standalone")
        self.assertIn(
            "/icons/jarvis-512.png",
            [item["src"] for item in manifest_data["icons"]],
        )
        self.assertEqual(worker.status_code, 200)
        self.assertIn(b"/api/", worker.content)
        self.assertEqual(icon.status_code, 200)
        self.assertIn(b"<svg", icon.content)
        self.assertEqual(png_icon.status_code, 200)
        self.assertEqual(png_icon.headers["content-type"], "image/png")

    def test_manual_login_accepts_the_full_generated_pairing_code(self):
        key = self.server.new_key()
        with patch("dashboard.server._jarvis_accent", return_value="#00d4ff"):
            login_page = self.client.get("/login")

        self.assertEqual(len(key), 8)
        self.assertEqual(login_page.headers["cache-control"], "no-store")
        self.assertIn("--accent: #00d4ff;", login_page.text)
        self.assertNotIn("#6366f1", login_page.text)
        self.assertIn('maxlength="8"', login_page.text)
        self.assertIn("inp.value.length === 8", login_page.text)
        self.assertIn("trusted HTTPS", login_page.text)
        self.assertNotIn("chrome://flags", login_page.text)
        self.assertIn("ONE-TIME CODE", login_page.text)
        response = self.client.post("/login", json={"pin": key})

        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["ok"])
        self.assertIn("token", response.json())

    def test_talk_screen_has_voice_companion_and_glasses_audio_setup(self):
        with patch("dashboard.server._jarvis_accent", return_value="#abcdef"):
            response = self.client.get("/")

        self.assertEqual(response.status_code, 200)
        self.assertIn("--accent:  #abcdef;", response.text)
        self.assertIn('id="voice-head"', response.text)
        self.assertIn('aria-live="polite"', response.text)
        self.assertIn('id="mic-meter"', response.text)
        self.assertIn('aria-label="Start listening with microphone"', response.text)
        self.assertIn("Pair Bluetooth glasses in your device", response.text)
        self.assertIn("Voice detected — streaming to JARVIS.", response.text)
        self.assertIn("nd.connect(ctx.destination);", response.text)
        self.assertIn("e.outputBuffer.getChannelData(0).fill(0)", response.text)
        self.assertNotIn("__JARVIS_ACCENT__", response.text)

    def test_file_manager_requires_auth_and_limits_delete_to_uploads(self):
        upload = self.server._uploads_dir / "notes.txt"
        upload.write_text("uploaded", encoding="utf-8")
        outside = self.root / "outside.txt"
        outside.write_text("protected", encoding="utf-8")
        link = self.server._uploads_dir / "linked.txt"
        link.symlink_to(outside)

        self.assertEqual(self.client.get("/api/files").status_code, 401)
        listed = self.client.get("/api/files", headers=self.headers)
        self.assertEqual(listed.status_code, 200)
        self.assertEqual([item["name"] for item in listed.json()["files"]], ["notes.txt"])
        self.assertEqual(
            self.client.get(
                "/uploads/linked.txt", params={"token": "test-token"}
            ).status_code,
            404,
        )

        deleted = self.client.delete("/api/files/notes.txt", headers=self.headers)
        self.assertEqual(deleted.status_code, 200)
        self.assertFalse(upload.exists())
        self.assertEqual(outside.read_text(encoding="utf-8"), "protected")
        self.assertEqual(
            self.client.delete("/api/files/missing.txt", headers=self.headers).status_code,
            404,
        )

    def test_audio_broadcast_drops_old_chunks_for_slow_clients(self):
        server = DashboardServer.__new__(DashboardServer)
        queue = asyncio.Queue(maxsize=2)
        server._audio_clients = {object(): queue}

        server.queue_audio(b"first")
        server.queue_audio(b"second")
        server.queue_audio(b"latest")

        self.assertEqual(queue.get_nowait(), b"second")
        self.assertEqual(queue.get_nowait(), b"latest")


if __name__ == "__main__":
    unittest.main()
