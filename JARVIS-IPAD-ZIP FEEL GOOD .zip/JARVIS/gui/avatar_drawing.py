"""Animated, validated whiteboard drawings for visual explanations."""
from __future__ import annotations

import math
import time
from dataclasses import dataclass
from typing import Any

from PyQt6.QtCore import QPointF, QRectF, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import (
    QColor, QFont, QLinearGradient, QPainter, QPainterPath, QPen,
    QRadialGradient,
)
from PyQt6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

from gui.style import px_font
from gui.theme import C


_SHAPES = {
    "box", "rounded_box", "circle", "ellipse", "boiler", "cylinder", "wheel",
    "piston", "chimney", "flame", "valve", "tank", "gear",
}


@dataclass(frozen=True)
class DrawingPart:
    shape: str
    x: float
    y: float
    width: float
    height: float
    label: str
    step: int


@dataclass(frozen=True)
class DrawingConnection:
    start: int
    end: int
    label: str
    step: int


@dataclass(frozen=True)
class DrawingStep:
    title: str
    explanation: str


@dataclass(frozen=True)
class VisualExplanation:
    title: str
    subtitle: str
    parts: tuple[DrawingPart, ...]
    connections: tuple[DrawingConnection, ...]
    steps: tuple[DrawingStep, ...]


def _bounded_text(value: Any, limit: int, fallback: str = "") -> str:
    if not isinstance(value, str):
        return fallback
    return " ".join(value.split())[:limit] or fallback


def _number(value: Any, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{field} must be a number.")
    number = float(value)
    if not math.isfinite(number):
        raise ValueError(f"{field} must be finite.")
    return number


def normalize_visual_explanation(data: Any) -> VisualExplanation:
    """Validate model-generated drawing instructions before they reach Qt."""
    if not isinstance(data, dict):
        raise ValueError("A visual explanation must be an object.")

    raw_steps = data.get("steps", [])
    if not isinstance(raw_steps, (list, tuple)) or not 1 <= len(raw_steps) <= 6:
        raise ValueError("A visual explanation needs between one and six steps.")
    steps: list[DrawingStep] = []
    for item in raw_steps:
        if not isinstance(item, dict):
            raise ValueError("Each explanation step must be an object.")
        steps.append(DrawingStep(
            _bounded_text(item.get("title"), 42, "Step"),
            _bounded_text(item.get("explanation"), 180),
        ))

    raw_parts = data.get("components", [])
    if not isinstance(raw_parts, (list, tuple)) or not 1 <= len(raw_parts) <= 14:
        raise ValueError("A drawing needs between one and fourteen components.")
    parts: list[DrawingPart] = []
    for item in raw_parts:
        if not isinstance(item, dict):
            raise ValueError("Each drawing component must be an object.")
        shape = _bounded_text(item.get("shape"), 20).lower()
        if shape not in _SHAPES:
            raise ValueError(f"Unsupported drawing shape: {shape or '(empty)'}.")
        x = _number(item.get("x"), "component x")
        y = _number(item.get("y"), "component y")
        width = _number(item.get("width"), "component width")
        height = _number(item.get("height"), "component height")
        step = item.get("step", 0)
        if isinstance(step, bool) or not isinstance(step, int):
            raise ValueError("Component step must be an integer.")
        if not (0.04 <= x <= 0.96 and 0.15 <= y <= 0.86
                and 0.025 <= width <= 0.72 and 0.025 <= height <= 0.55
                and x - width / 2 >= 0.02 and x + width / 2 <= 0.98
                and y - height / 2 >= 0.12 and y + height / 2 <= 0.90
                and 0 <= step < len(steps)):
            raise ValueError("Drawing component is outside the allowed canvas.")
        parts.append(DrawingPart(
            shape, x, y, width, height,
            _bounded_text(item.get("label"), 34), step,
        ))

    raw_connections = data.get("connections", [])
    if not isinstance(raw_connections, (list, tuple)) or len(raw_connections) > 18:
        raise ValueError("A drawing can have at most eighteen connections.")
    connections: list[DrawingConnection] = []
    for item in raw_connections:
        if not isinstance(item, dict):
            raise ValueError("Each drawing connection must be an object.")
        start, end = item.get("from"), item.get("to")
        default_step = (
            max(start, end)
            if isinstance(start, int) and not isinstance(start, bool)
            and isinstance(end, int) and not isinstance(end, bool)
            else 0
        )
        step = item.get("step", default_step)
        if (isinstance(start, bool) or not isinstance(start, int)
                or isinstance(end, bool) or not isinstance(end, int)
                or not 0 <= start < len(parts) or not 0 <= end < len(parts)
                or isinstance(step, bool) or not isinstance(step, int)
                or not 0 <= step < len(steps)):
            raise ValueError("Drawing connections must reference valid components and steps.")
        connections.append(DrawingConnection(
            start, end, _bounded_text(item.get("label"), 28), step
        ))

    return VisualExplanation(
        _bounded_text(data.get("title"), 72, "Visual explanation"),
        _bounded_text(data.get("subtitle"), 120),
        tuple(parts), tuple(connections), tuple(steps),
    )


def _path_for_part(part: DrawingPart, page: QRectF) -> QPainterPath:
    rect = QRectF(
        page.left() + part.x * page.width() - part.width * page.width() / 2,
        page.top() + part.y * page.height() - part.height * page.height() / 2,
        part.width * page.width(),
        part.height * page.height(),
    )
    path = QPainterPath()
    if part.shape == "cylinder":
        cap = min(rect.height() * 0.22, rect.width() * 0.28)
        path.addEllipse(QRectF(rect.left(), rect.top(), rect.width(), cap * 2))
        path.moveTo(rect.left(), rect.top() + cap)
        path.lineTo(rect.left(), rect.bottom() - cap)
        path.moveTo(rect.right(), rect.top() + cap)
        path.lineTo(rect.right(), rect.bottom() - cap)
        path.addEllipse(QRectF(
            rect.left(), rect.bottom() - cap * 2, rect.width(), cap * 2
        ))
    elif part.shape in ("box", "rounded_box", "tank", "boiler"):
        if part.shape == "rounded_box":
            path.addRoundedRect(rect, rect.height() * 0.08, rect.height() * 0.08)
        else:
            path.addRect(rect)
        if part.shape in ("tank", "boiler"):
            path.moveTo(rect.left() + rect.width() * 0.12, rect.top())
            path.lineTo(rect.left() + rect.width() * 0.12, rect.bottom())
            path.moveTo(rect.right() - rect.width() * 0.12, rect.top())
            path.lineTo(rect.right() - rect.width() * 0.12, rect.bottom())
            path.moveTo(rect.left(), rect.center().y())
            path.lineTo(rect.right(), rect.center().y())
    elif part.shape in ("circle", "ellipse", "wheel"):
        path.addEllipse(rect)
        if part.shape == "wheel":
            path.addEllipse(rect.adjusted(
                rect.width() * 0.23, rect.height() * 0.23,
                -rect.width() * 0.23, -rect.height() * 0.23,
            ))
            for angle in range(0, 360, 45):
                radians = math.radians(angle)
                path.moveTo(rect.center())
                path.lineTo(QPointF(
                    rect.center().x() + math.cos(radians) * rect.width() * 0.46,
                    rect.center().y() + math.sin(radians) * rect.height() * 0.46,
                ))
    elif part.shape == "piston":
        path.addRoundedRect(rect.adjusted(
            rect.width() * 0.18, rect.height() * 0.24,
            -rect.width() * 0.18, -rect.height() * 0.24,
        ), rect.height() * 0.08, rect.height() * 0.08)
        path.moveTo(rect.left(), rect.center().y())
        path.lineTo(rect.right(), rect.center().y())
        path.moveTo(rect.center().x(), rect.top())
        path.lineTo(rect.center().x(), rect.bottom())
    elif part.shape == "chimney":
        path.moveTo(rect.left() + rect.width() * 0.22, rect.bottom())
        path.lineTo(rect.left() + rect.width() * 0.30, rect.top())
        path.lineTo(rect.right() - rect.width() * 0.30, rect.top())
        path.lineTo(rect.right() - rect.width() * 0.22, rect.bottom())
        path.closeSubpath()
        path.moveTo(rect.left() + rect.width() * 0.16, rect.top())
        path.lineTo(rect.right() - rect.width() * 0.16, rect.top())
    elif part.shape == "flame":
        path.moveTo(rect.center().x(), rect.top())
        path.cubicTo(rect.left(), rect.top() + rect.height() * 0.44,
                     rect.left() + rect.width() * 0.22, rect.bottom(),
                     rect.center().x(), rect.bottom())
        path.cubicTo(rect.right() - rect.width() * 0.15,
                     rect.top() + rect.height() * 0.84,
                     rect.right(), rect.top() + rect.height() * 0.34,
                     rect.center().x(), rect.top())
    elif part.shape == "valve":
        path.moveTo(rect.left(), rect.center().y())
        path.lineTo(rect.center().x(), rect.top())
        path.lineTo(rect.right(), rect.center().y())
        path.lineTo(rect.center().x(), rect.bottom())
        path.closeSubpath()
        path.moveTo(rect.center().x(), rect.top())
        path.lineTo(rect.center().x(), rect.top() - rect.height() * 0.28)
        path.moveTo(rect.center().x() - rect.width() * 0.22,
                    rect.top() - rect.height() * 0.28)
        path.lineTo(rect.center().x() + rect.width() * 0.22,
                    rect.top() - rect.height() * 0.28)
    elif part.shape == "gear":
        path.addEllipse(rect)
        for angle in range(0, 360, 45):
            radians = math.radians(angle)
            path.moveTo(QPointF(
                rect.center().x() + math.cos(radians) * rect.width() * 0.35,
                rect.center().y() + math.sin(radians) * rect.height() * 0.35,
            ))
            path.lineTo(QPointF(
                rect.center().x() + math.cos(radians) * rect.width() * 0.50,
                rect.center().y() + math.sin(radians) * rect.height() * 0.50,
            ))
        path.addEllipse(rect.adjusted(
            rect.width() * 0.32, rect.height() * 0.32,
            -rect.width() * 0.32, -rect.height() * 0.32,
        ))
    return path


def _part_center(part: DrawingPart, diagram: QRectF) -> QPointF:
    return QPointF(
        diagram.left() + part.x * diagram.width(),
        diagram.top() + part.y * diagram.height(),
    )


def _connection_edge(part: DrawingPart, toward: QPointF,
                     diagram: QRectF) -> QPointF:
    center = _part_center(part, diagram)
    dx, dy = toward.x() - center.x(), toward.y() - center.y()
    half_width = part.width * diagram.width() / 2
    half_height = part.height * diagram.height() / 2
    if abs(dx) < 1e-6 and abs(dy) < 1e-6:
        return center
    scale_x = half_width / abs(dx) if abs(dx) > 1e-6 else float("inf")
    scale_y = half_height / abs(dy) if abs(dy) > 1e-6 else float("inf")
    scale = min(scale_x, scale_y)
    return QPointF(center.x() + dx * scale, center.y() + dy * scale)


class DrawingCanvas(QWidget):
    """A paper-like board that zooms in, then traces each diagram stroke."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(360, 260)
        self.plan: VisualExplanation | None = None
        self._started_at = 0.0
        self._elapsed = 0.0
        self._timer = QTimer(self)
        self._timer.setInterval(33)
        self._timer.timeout.connect(self._tick)

    def start(self, data: Any) -> None:
        self.plan = normalize_visual_explanation(data)
        self._started_at = time.monotonic()
        self._elapsed = 0.0
        self._timer.start()
        self.update()

    def stop(self) -> None:
        self._timer.stop()

    def _tick(self) -> None:
        self._elapsed = time.monotonic() - self._started_at
        total = 0.9 + len(self.plan.steps) * 1.15 if self.plan else 0.0
        if self._elapsed >= total:
            self._elapsed = total
            self._timer.stop()
        self.update()

    def paintEvent(self, _event) -> None:
        if self.plan is None:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), QColor(C.BG))
        zoom = min(1.0, max(0.0, self._elapsed / 0.9))
        zoom = 1.0 - (1.0 - zoom) ** 3
        full = QRectF(self.rect()).adjusted(12, 12, -12, -12)
        paper_w = full.width() * (0.18 + 0.82 * zoom)
        paper_h = full.height() * (0.22 + 0.78 * zoom)
        page = QRectF(0, 0, paper_w, paper_h)
        page.moveCenter(full.center())

        shadow = page.translated(0, max(2.0, page.height() * 0.012))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(0, 0, 0, 150))
        p.drawRoundedRect(shadow, 9, 9)
        paper_gradient = QLinearGradient(page.topLeft(), page.bottomRight())
        paper_gradient.setColorAt(0.0, QColor("#f4fbff"))
        paper_gradient.setColorAt(1.0, QColor("#dceaf2"))
        p.setBrush(paper_gradient)
        p.drawRoundedRect(page, 8, 8)

        p.save()
        p.setClipRect(page.adjusted(6, 6, -6, -6))
        ink = QColor("#07344a")
        faint = QColor("#9db9c6")
        p.setPen(QPen(QColor(20, 98, 125, 22), 0.7))
        grid = max(18.0, page.width() * 0.027)
        x = page.left()
        while x <= page.right():
            p.drawLine(QPointF(x, page.top()), QPointF(x, page.bottom()))
            x += grid
        y = page.top()
        while y <= page.bottom():
            p.drawLine(QPointF(page.left(), y), QPointF(page.right(), y))
            y += grid

        p.setPen(QPen(ink, 1))
        title_font = px_font(max(14, page.width() * 0.026), QFont.Weight.Bold)
        p.setFont(title_font)
        title_rect = QRectF(page.left() + 28, page.top() + 18,
                            page.width() - 56, page.height() * 0.065)
        p.drawText(title_rect, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                   self.plan.title)
        p.setFont(px_font(max(9, page.width() * 0.014)))
        p.setPen(QPen(QColor("#326779"), 0.8))
        subtitle_rect = QRectF(title_rect.left(), title_rect.bottom() + 2,
                               title_rect.width(), page.height() * 0.045)
        p.drawText(subtitle_rect, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                   self.plan.subtitle)

        diagram = QRectF(page.left() + page.width() * 0.08,
                         page.top() + page.height() * 0.20,
                         page.width() * 0.84, page.height() * 0.57)
        draw_duration = max(0.1, len(self.plan.steps) * 1.15)
        draw_progress = max(0.0, min(1.0, (self._elapsed - 0.9) / draw_duration))

        connection_labels: list[tuple[QPointF, str]] = []
        for connection in self.plan.connections:
            part = self.plan.parts[connection.start]
            target = self.plan.parts[connection.end]
            order = max(part.step, target.step, connection.step)
            progress = draw_progress * len(self.plan.steps) - order
            if progress <= 0:
                continue
            start_center = _part_center(part, diagram)
            end_center = _part_center(target, diagram)
            start = _connection_edge(part, end_center, diagram)
            end = _connection_edge(target, start_center, diagram)
            _draw_segment(p, start, end, progress, ink, 2.0)
            if progress >= 1.0 and connection.label:
                mid = QPointF((start.x() + end.x()) / 2,
                              (start.y() + end.y()) / 2)
                vx, vy = end.y() - start.y(), start.x() - end.x()
                length = max(1.0, math.hypot(vx, vy))
                mid = QPointF(mid.x() + vx / length * 22,
                              mid.y() + vy / length * 22)
                connection_labels.append((mid, connection.label))

        for part in self.plan.parts:
            progress = draw_progress * len(self.plan.steps) - part.step
            if progress <= 0:
                continue
            path = _path_for_part(part, diagram)
            _draw_path_progress(p, path, min(1.0, progress), ink, 2.1)
            if progress >= 1.0 and part.label:
                bounds = path.boundingRect()
                p.setPen(QPen(ink, 0.9))
                p.setFont(px_font(max(8, page.width() * 0.013), QFont.Weight.Bold))
                label_rect = QRectF(bounds.left() - 12, bounds.bottom() + 3,
                                    bounds.width() + 24, page.height() * 0.038)
                p.drawText(label_rect, Qt.AlignmentFlag.AlignHCenter |
                           Qt.AlignmentFlag.AlignTop | Qt.TextFlag.TextWordWrap,
                           part.label)

        p.setPen(QPen(ink, 0.8))
        p.setFont(px_font(max(8, page.width() * 0.012), QFont.Weight.DemiBold))
        for point, label in connection_labels:
            metrics = p.fontMetrics()
            label_width = metrics.horizontalAdvance(label) + 8
            label_height = metrics.height()
            p.drawText(QRectF(point.x() - label_width / 2,
                              point.y() - label_height / 2,
                              label_width, label_height),
                       Qt.AlignmentFlag.AlignCenter, label)

        p.setPen(QPen(faint, 0.8))
        footer_y = page.top() + page.height() * 0.81
        p.drawLine(QPointF(page.left() + 28, footer_y),
                   QPointF(page.right() - 28, footer_y))
        current_step = min(
            len(self.plan.steps) - 1,
            max(0, int(max(0.0, self._elapsed - 0.9) / 1.15)),
        )
        step = self.plan.steps[current_step]
        p.setPen(QPen(QColor("#0b718e"), 1.0))
        p.setFont(px_font(max(10, page.width() * 0.016), QFont.Weight.Bold))
        p.drawText(QRectF(page.left() + 28, footer_y + 9,
                          page.width() - 56, page.height() * 0.045),
                   Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                   f"{current_step + 1:02d} / {len(self.plan.steps):02d}   {step.title}")
        p.setPen(QPen(ink, 0.85))
        p.setFont(px_font(max(9, page.width() * 0.014)))
        p.drawText(QRectF(page.left() + 28, footer_y + page.height() * 0.055,
                          page.width() - 56, page.height() * 0.11),
                   Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop |
                   Qt.TextFlag.TextWordWrap, step.explanation)
        p.restore()
        p.end()


def _draw_segment(p: QPainter, start: QPointF, end: QPointF, progress: float,
                  color: QColor, width: float) -> None:
    amount = max(0.0, min(1.0, progress))
    if amount <= 0.0:
        return
    partial = QPointF(
        start.x() + (end.x() - start.x()) * amount,
        start.y() + (end.y() - start.y()) * amount,
    )
    p.setPen(QPen(color, width, Qt.PenStyle.SolidLine,
                  Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
    p.drawLine(start, partial)
    if amount >= 1.0:
        _arrow = QPainterPath()
        angle = math.atan2(end.y() - start.y(), end.x() - start.x())
        size = 8.0
        for offset in (2.55, -2.55):
            _arrow.moveTo(end)
            _arrow.lineTo(QPointF(
                end.x() + math.cos(angle + offset) * size,
                end.y() + math.sin(angle + offset) * size,
            ))
        p.drawPath(_arrow)


def _draw_path_progress(p: QPainter, path: QPainterPath, progress: float,
                        color: QColor, width: float) -> None:
    amount = max(0.0, min(1.0, progress))
    bounds = path.boundingRect()
    if amount <= 0.0 or bounds.isEmpty():
        return
    p.save()
    p.setClipRect(QRectF(bounds.left() - width, bounds.top() - width,
                         bounds.width() * amount + width * 2,
                         bounds.height() + width * 2))
    p.setPen(QPen(color, width, Qt.PenStyle.SolidLine,
                  Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
    p.drawPath(path)
    p.restore()


class DrawingBoard(QWidget):
    """HUD page containing the animated sheet and a clear, reachable close."""

    close_requested = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("VisualExplanationBoard")
        self.setStyleSheet(f"background: {C.BG};")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        header = QHBoxLayout()
        header.setContentsMargins(10, 5, 10, 5)
        self._status = QLabel("◈  LIVE EXPLANATION")
        self._status.setFont(px_font(9, QFont.Weight.Bold))
        self._status.setStyleSheet(f"color: {C.PRI}; background: transparent;")
        header.addWidget(self._status)
        header.addStretch()
        close = QPushButton("✕  CLOSE")
        close.setFont(px_font(9, QFont.Weight.Bold))
        close.setCursor(Qt.CursorShape.PointingHandCursor)
        close.setStyleSheet(f"""
            QPushButton {{ color: {C.TEXT_DIM}; background: transparent;
                           border: none; padding: 5px 8px; }}
            QPushButton:hover {{ color: {C.PRI}; }}
        """)
        close.clicked.connect(self.close_requested.emit)
        header.addWidget(close)
        layout.addLayout(header)
        self.canvas = DrawingCanvas(self)
        layout.addWidget(self.canvas, stretch=1)

    def start(self, data: Any) -> None:
        self.canvas.start(data)
        self._status.setText("◈  DRAWING IN REAL TIME")