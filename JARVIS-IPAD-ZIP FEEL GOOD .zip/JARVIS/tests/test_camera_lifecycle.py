import os
import threading
import tempfile
import time
import unittest
from pathlib import Path
from types import MethodType
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock
from unittest.mock import patch

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QApplication,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSplitter,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from actions.science_mode import science_mode as science_mode_action
from actions import code_helper
from actions.code_helper import DESKTOP, _resolve_save_path
from core import science_mode
from gui.theme import C, current_palette
from gui.window import MainWindow
from main import JarvisLive


class CameraVisionLifecycleTests(unittest.IsolatedAsyncioTestCase):
    async def test_camera_preview_stays_open_after_vision_answer(self):
        live = JarvisLive.__new__(JarvisLive)
        live._lock_mode_active = False
        live._pending_vision = (
            b"current-frame",
            "image/jpeg",
            "Describe what is in view.",
            "camera",
        )
        live._vision_response_pending = False
        live._vision_busy = True
        live.session = Mock(send_client_content=AsyncMock())
        live.ui = Mock()

        self.assertTrue(await live._flush_pending_vision())
        self.assertTrue(live._vision_response_pending)
        self.assertTrue(live._vision_busy)

        live._release_vision_after_response()

        self.assertFalse(live._vision_response_pending)
        self.assertFalse(live._vision_busy)
        live.ui.stop_camera_stream.assert_not_called()
        sent = live.session.send_client_content.await_args.kwargs
        self.assertIn("WEBCAM", sent["turns"]["parts"][1]["text"])

    async def test_failed_camera_analysis_releases_vision_lock_without_closing_feed(self):
        live = JarvisLive.__new__(JarvisLive)
        live._lock_mode_active = False
        live._pending_vision = (
            b"current-frame",
            "image/jpeg",
            "Describe what is in view.",
            "camera",
        )
        live._vision_response_pending = False
        live._vision_busy = True
        live.session = Mock(
            send_client_content=AsyncMock(side_effect=RuntimeError("session closed"))
        )
        live.ui = Mock()

        with self.assertRaisesRegex(RuntimeError, "session closed"):
            await live._flush_pending_vision()

        self.assertFalse(live._vision_response_pending)
        self.assertFalse(live._vision_busy)
        live.ui.stop_camera_stream.assert_not_called()


class CameraStreamThreadTests(unittest.TestCase):
    def test_start_camera_stream_does_not_duplicate_a_live_capture(self):
        started = threading.Event()
        release = threading.Event()

        def capture():
            started.set()
            release.wait(timeout=2)

        window = SimpleNamespace(
            _cam_thread_lock=threading.Lock(),
            _cam_thread=None,
            _cam_stop=threading.Event(),
            _cam_stream_sig=Mock(),
            _cam_loop=capture,
        )

        try:
            MainWindow.start_camera_stream(window)
            first_thread = window._cam_thread
            self.assertTrue(started.wait(timeout=1))

            MainWindow.start_camera_stream(window)

            self.assertIs(window._cam_thread, first_thread)
            window._cam_stream_sig.emit.assert_called_once_with(True)
        finally:
            window._cam_stop.set()
            release.set()
            if window._cam_thread:
                window._cam_thread.join(timeout=1)

    def test_science_monitor_reads_frames_only_from_an_active_preview(self):
        window = SimpleNamespace(
            _cam_thread_lock=threading.Lock(),
            _cam_thread=SimpleNamespace(is_alive=lambda: True),
            _cam_stop=threading.Event(),
            _cam_frame_lock=threading.Lock(),
            _cam_latest_frame=b"preview-jpeg",
        )
        window.camera_stream_active = lambda: MainWindow.camera_stream_active(window)

        self.assertTrue(MainWindow.camera_stream_active(window))
        self.assertEqual(MainWindow.latest_camera_frame(window), b"preview-jpeg")

        window._cam_stop.set()
        self.assertFalse(MainWindow.camera_stream_active(window))
        self.assertIsNone(MainWindow.latest_camera_frame(window))


class ScienceModeTests(unittest.IsolatedAsyncioTestCase):
    def tearDown(self):
        science_mode.stop()

    def test_science_state_starts_updates_and_stops(self):
        started = science_mode.start("Water cycle observation")
        self.assertTrue(started.active)
        self.assertEqual(started.experiment, "Water cycle observation")

        updated = science_mode.start("  Salt   crystal growth  ")
        self.assertTrue(updated.active)
        self.assertEqual(updated.experiment, "Salt crystal growth")

        stopped = science_mode.stop()
        self.assertFalse(stopped.active)
        self.assertEqual(stopped.experiment, "")

    def test_science_state_tracks_materials_and_sequential_steps(self):
        science_mode.start(
            "Plant growth",
            materials=["Cup", "Water"],
            steps=["Prepare the cup.", "Record the observation."],
        )

        updated = science_mode.update(
            available_materials=["cup"],
            completed_step=1,
        )

        self.assertEqual(updated.available_materials, ("Cup",))
        self.assertEqual(updated.completed_steps, 1)
        toggled = science_mode.set_material_available("Water", True)
        self.assertEqual(toggled.available_materials, ("Cup", "Water"))

    def test_science_plan_rejects_topics_marked_outside_safe_limits(self):
        with patch.object(science_mode.gemini, "as_json") as analyze:
            self.assertIsNone(science_mode.generate_plan("Build an explosive"))
        analyze.assert_not_called()

        with patch.object(
            science_mode.gemini,
            "as_json",
            return_value={
                "safe": False,
                "materials": ["reactive chemicals"],
                "steps": ["Mix them."],
            },
        ):
            self.assertIsNone(science_mode.generate_plan("Unknown chemical reaction"))

    def test_science_plan_normalizes_bounded_safe_plan(self):
        with patch.object(
            science_mode.gemini,
            "as_json",
            return_value={
                "safe": True,
                "materials": [" Water ", "water", "Clear cup"],
                "steps": [" Observe the level. ", "Record the change."],
                "note": " Use ordinary classroom supplies. ",
            },
        ):
            result = science_mode.generate_plan("Observe evaporation")

        self.assertEqual(result["materials"], ("Water", "Clear cup"))
        self.assertEqual(result["steps"], ("Observe the level.", "Record the change."))

    def test_science_plan_rejects_unsafe_generated_materials(self):
        with patch.object(
            science_mode.gemini,
            "as_json",
            return_value={
                "safe": True,
                "materials": ["Candle", "Water"],
                "steps": ["Observe the surface."],
            },
        ):
            self.assertIsNone(science_mode.generate_plan("Observe a water surface"))

    def test_science_start_returns_generated_plan_for_voice_guidance(self):
        player = Mock()
        player.camera_stream_active.return_value = True
        plan = {
            "materials": ("Water", "Clear cup"),
            "steps": ("Add water to the cup.", "Observe the level."),
            "note": "",
        }

        with patch.object(science_mode, "generate_plan", return_value=plan):
            message = science_mode_action(
                {"action": "start", "experiment": "Observe water level"},
                player=player,
            )

        self.assertIn("Materials needed: Water, Clear cup", message)
        self.assertIn("1. Add water to the cup.", message)
        self.assertEqual(science_mode.snapshot().steps, plan["steps"])

    def test_science_update_marks_only_user_confirmed_material_and_step(self):
        science_mode.start(
            "Observe water level",
            materials=["Water", "Clear cup"],
            steps=["Add water.", "Record the level."],
        )

        message = science_mode_action(
            {
                "action": "update",
                "material": "Water",
                "have_material": True,
                "completed_step": 1,
            }
        )

        current = science_mode.snapshot()
        self.assertEqual(current.available_materials, ("Water",))
        self.assertEqual(current.completed_steps, 1)
        self.assertIn("2: Record the level.", message)

    def test_only_high_confidence_valid_observations_become_alerts(self):
        self.assertIsNone(science_mode.normalize_alert({
            "alert": True,
            "severity": "caution",
            "confidence": 0.84,
            "warning": "Maybe something is wrong.",
        }))
        alert = science_mode.normalize_alert({
            "alert": True,
            "severity": "urgent",
            "confidence": 0.75,
            "warning": "  Pause; visible smoke is rising.  ",
        })
        self.assertEqual(alert["warning"], "Pause; visible smoke is rising.")
        self.assertIsNone(science_mode.normalize_alert({
            "alert": True,
            "severity": "urgent",
            "confidence": float("nan"),
            "warning": "Unsafe.",
        }))

    def test_frame_analysis_uses_a_single_image_and_experiment_context(self):
        response = {
            "alert": True,
            "severity": "caution",
            "confidence": 0.9,
            "warning": "Pause; the vessel looks unstable.",
        }
        with patch.object(science_mode.gemini, "as_json", return_value=response) as analyze:
            result = science_mode.analyze_frame(b"jpeg-bytes", "Water evaporation")

        contents = analyze.call_args.args[0]
        self.assertEqual(contents[0].inline_data.mime_type, "image/jpeg")
        self.assertEqual(contents[0].inline_data.data, b"jpeg-bytes")
        self.assertIn("Water evaporation", contents[1])
        self.assertEqual(result["warning"], "Pause; the vessel looks unstable.")

    def test_start_does_not_open_camera_automatically(self):
        player = Mock()
        player.camera_stream_active.return_value = False

        with patch.object(science_mode, "generate_plan", return_value=None):
            message = science_mode_action(
                {"action": "start", "experiment": "Measuring water evaporation"},
                player=player,
            )

        self.assertTrue(science_mode.snapshot().active)
        self.assertIn("Camera checks are paused", message)
        player.start_camera_stream.assert_not_called()
        player.write_log.assert_called_once()
        player.show_science_workspace.assert_called_once()

    async def test_observer_samples_without_experiment_even_while_jarvis_speaks(self):
        live = self._live(camera_active=True)
        live._is_speaking = True
        state = science_mode.ScienceModeState(True, "", 1)

        with (
            patch.object(science_mode, "snapshot", return_value=state),
            patch.object(science_mode, "analyze_frame", return_value=None) as analyze,
        ):
            await live._science_monitor_once()

        analyze.assert_called_once_with(b"current-jpeg", "")

    async def test_monitor_does_not_capture_when_camera_is_closed(self):
        live = self._live(camera_active=False)
        state = science_mode.ScienceModeState(True, "Plant growth", 1)

        with (
            patch.object(science_mode, "snapshot", return_value=state),
            patch.object(science_mode, "analyze_frame") as analyze,
        ):
            await live._science_monitor_once()

        analyze.assert_not_called()
        live.ui.latest_camera_frame.assert_not_called()
        live.session.send_client_content.assert_not_awaited()

    async def test_monitor_delivers_a_valid_warning_once(self):
        live = self._live(camera_active=True)
        state = science_mode.ScienceModeState(True, "Plant growth", 1)
        candidate = {
            "severity": "caution",
            "confidence": 0.9,
            "warning": "Pause; the container appears unstable.",
        }

        with (
            patch.object(science_mode, "snapshot", return_value=state),
            patch.object(science_mode, "analyze_frame", return_value=candidate),
        ):
            await live._science_monitor_once()
            await live._science_monitor_once()

        self.assertEqual(
            live.session.send_client_content.await_count,
            1,
        )
        sent = live.session.send_client_content.await_args.kwargs
        self.assertIn("science-observer", sent["turns"]["parts"][0]["text"])
        self.assertIn("container appears unstable", sent["turns"]["parts"][0]["text"])

    async def test_monitor_defers_warning_until_user_is_idle(self):
        live = self._live(camera_active=True)
        live._science_pending_alert = "Pause; the container appears unstable."
        live._last_user_speech = time.monotonic()
        state = science_mode.ScienceModeState(True, "Plant growth", 1)

        with patch.object(science_mode, "snapshot", return_value=state):
            delivered = await live._deliver_science_alert()

        self.assertFalse(delivered)
        self.assertEqual(
            live._science_pending_alert,
            "Pause; the container appears unstable.",
        )
        live.session.send_client_content.assert_not_awaited()

    def _live(self, camera_active):
        live = JarvisLive.__new__(JarvisLive)
        live.session = Mock(send_client_content=AsyncMock())
        live.ui = Mock()
        live.ui.camera_stream_active.return_value = camera_active
        live.ui.latest_camera_frame.return_value = b"current-jpeg"
        live._engine_caps = None
        live._awake = True
        live._lock_mode_active = False
        live._lock_mode_pending = False
        live._lock_mode_discard_until_user_turn = False
        live._vision_busy = False
        live._vision_response_pending = False
        live._science_busy = False
        live._science_analysis_lock = threading.Lock()
        live._science_pending_alert = None
        live._science_last_alert_key = ""
        live._science_last_alert_time = 0.0
        live._science_generation = -1
        live._is_speaking = False
        live._speaking_lock = threading.Lock()
        live._last_user_speech = time.monotonic() - 30
        return live


class ScienceWorkspaceUiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def test_science_workspace_keeps_blue_and_left_panel_unchanged(self):
        root = QWidget()
        layout = QHBoxLayout(root)
        left, right = QFrame(), QFrame()
        left.setFixedWidth(148)
        split = QSplitter(Qt.Orientation.Vertical)
        hud, content, quiz, science = (QFrame() for _ in range(4))
        for widget in (hud, content, quiz, science):
            split.addWidget(widget)
        science.hide()
        layout.addWidget(left)
        layout.addWidget(split)
        layout.addWidget(right)
        root.show()
        self.app.processEvents()

        science_body = QWidget()
        science_body_layout = QVBoxLayout(science_body)
        materials_body, steps_body = QWidget(), QWidget()
        materials_layout, steps_layout = QVBoxLayout(materials_body), QVBoxLayout(steps_body)
        science_body_layout.addWidget(materials_body)
        science_body_layout.addWidget(steps_body)
        QVBoxLayout(science).addWidget(science_body)

        class Panel:
            def __init__(self, title, code):
                self._title = title
                self._code = code

            def set_title(self, title):
                self._title = title

            def set_code(self, code):
                self._code = code

        task_stack = QStackedWidget(left)
        task_stack.addWidget(QFrame())
        task_stack.addWidget(QFrame())
        left_layout = Mock()
        toggles = []
        window = SimpleNamespace(
            _science_enabled=False,
            _science_previous_visibility=(False, False, False, ""),
            _content_panel=content,
            _quiz_panel=quiz,
            _right_panel=right,
            _science_panel=science,
            _center_split=split,
            _left_layout=left_layout,
            _systems_panel=Panel("SYSTEMS", "LIVE"),
            _systems_grid=QFrame(left),
            _science_experiment_left=QLabel(left),
            _science_camera_left=QLabel(left),
            _net_panel=Panel("NETWORK", "--"),
            _net_spark=QFrame(left),
            _science_focus_left=QLabel(left),
            _status_panel=Panel("STATUS", ""),
            _status_rows=[QFrame(left), QFrame(left)],
            _science_materials_scroll=QFrame(left),
            _tasks_panel=Panel("TASKS", ""),
            _tasks_stack=task_stack,
            _panel_switch=QPushButton("ROUTINES", left),
            _science_steps_scroll=QFrame(left),
            _science_experiment_lbl=QLabel(),
            _science_camera_lbl=QLabel(),
            _science_research_lbl=QLabel(),
            _science_materials_layout=materials_layout,
            _science_steps_layout=steps_layout,
            _sub_lbl=QLabel("JARVIS"),
            _refresh_tasks=lambda: None,
            _refresh_status_strip=lambda: None,
            on_science_material_toggle=lambda name, checked: toggles.append(
                (name, checked)
            ),
        )
        window._clear_layout = MethodType(MainWindow._clear_layout, window)
        window._reveal_below_hud = MethodType(MainWindow._reveal_below_hud, window)
        window._science_material_toggled = MethodType(
            MainWindow._science_material_toggled, window
        )
        window._set_science_camera_state = MethodType(
            MainWindow._set_science_camera_state, window
        )
        before = current_palette()
        left_width = left.width()
        try:
            MainWindow._show_science_workspace(
                window,
                True,
                "Observe plant growth",
                ["Water"],
                [],
                ["Record the leaves."],
                0,
                False,
            )
            self.app.processEvents()

            self.assertEqual(C.PRI, before["PRI"])
            self.assertEqual(current_palette(), before)
            self.assertTrue(science.isVisible())
            self.assertTrue(left.isVisible())
            self.assertEqual(left.width(), left_width)
            self.assertFalse(right.isVisible())
            self.assertEqual(window._sub_lbl.text(), "SCIENCE LAB · ACTIVE EXPERIMENT")
            self.assertEqual(window._systems_panel._title, "EXPERIMENT")
            self.assertEqual(window._net_panel._title, "OBSERVATIONS")
            self.assertEqual(window._status_panel._title, "MATERIALS")
            self.assertEqual(window._tasks_panel._title, "STEPS")
            left_layout.setStretch.assert_any_call(2, 2)
            self.assertGreaterEqual(
                window._science_materials_scroll.minimumHeight(), 120
            )
            material = window._science_materials_layout.itemAt(0).widget()
            self.assertTrue(material.text().startswith("✕"))
            self.assertIn(C.GREEN, material.styleSheet())
            window._set_science_camera_state(True)
            self.assertIn(C.GREEN, window._science_camera_lbl.styleSheet())
            material.click()
            self.assertEqual(toggles, [("Water", True)])

            MainWindow._show_science_workspace(
                window, False, "", [], [], [], 0, False
            )
            self.assertEqual(current_palette(), before)
            self.assertFalse(science.isVisible())
            self.assertTrue(left.isVisible())
            self.assertTrue(right.isVisible())
            self.assertEqual(window._sub_lbl.text(), "JARVIS")
            self.assertEqual(window._systems_panel._title, "SYSTEMS")
            self.assertEqual(window._net_panel._title, "NETWORK")
            self.assertEqual(window._status_panel._title, "STATUS")
            self.assertEqual(window._tasks_panel._title, "TASKS")
            left_layout.setStretch.assert_any_call(2, 0)
            self.assertEqual(window._science_materials_scroll.minimumHeight(), 0)
        finally:
            if window._science_enabled:
                MainWindow._show_science_workspace(
                    window, False, "", [], [], [], 0, False
                )
            root.close()
            self.app.processEvents()


class OpenScadPathTests(unittest.TestCase):
    def test_openscad_designs_use_scad_extension_on_desktop(self):
        self.assertEqual(
            _resolve_save_path("", "openscad"),
            DESKTOP / "jarvis_code.scad",
        )

    def test_write_saves_self_contained_model_and_rejects_external_files(self):
        response = SimpleNamespace(text="cube([10, 10, 10], center = true);")
        model = SimpleNamespace(generate_content=Mock(return_value=response))
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "stand.scad"
            with patch.object(code_helper, "_get_gemini", return_value=model):
                source, saved_path = code_helper._write(
                    "A small stand", "openscad", str(path)
                )

            self.assertEqual(saved_path, path)
            self.assertEqual(path.read_text(encoding="utf-8"), source)

            response.text = "include <private.scad>;\ncube(10);"
            rejected_path = Path(temp_dir) / "rejected.scad"
            with patch.object(code_helper, "_get_gemini", return_value=model):
                with self.assertRaisesRegex(ValueError, "external file"):
                    code_helper._write(
                        "A stand using an external model", "openscad",
                        str(rejected_path),
                    )
            self.assertFalse(rejected_path.exists())


if __name__ == "__main__":
    unittest.main()
